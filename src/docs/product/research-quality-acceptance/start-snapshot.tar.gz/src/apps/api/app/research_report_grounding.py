"""Conservative, deterministic checks for checkpointed report clauses.

Location and lexical checks are not semantic verification; findings remain reviewable.
"""
import re
from decimal import Decimal, InvalidOperation
from typing import Any

_NUMBER = re.compile(r'(?<![\w])[-+]?\d[\d,]*(?:\.\d+)?(?![\w])')
_CAUSE = re.compile(r'\b(?:caused|causes|because|due to|led to|driven by)\b|导致|造成|由于|因为|推动', re.I)
_INFERENCE = re.compile(r'\b(?:may|might|could|hypothesis|inference|scenario)\b|可能|假设|推测|情景', re.I)
_CAMEL = re.compile(r'\b[A-Z][a-z]+[A-Z][A-Za-z]*\b|\b[A-Z]{2,6}\b')
_IGNORE = {'USD', 'EUR', 'CNY', 'HKD', 'FY', 'SEC', 'ETF'}


def _numbers(text: str) -> set[Decimal]:
    out = set()
    for value in _NUMBER.findall(text):
        try:
            out.add(Decimal(value.replace(',', '')))
        except InvalidOperation:
            continue
    return out


def clause_problem(text: str, quotations: list[str], facts: list[dict[str, Any]], calculations: list[dict[str, Any]]) -> str | None:
    evidence = ' '.join(quotations)
    if not evidence:
        return 'A located quotation is required.'
    allowed = _numbers(evidence)
    for item in [*facts, *calculations]:
        allowed |= _numbers(' '.join(str(item.get(k) or '') for k in ('value', 'period', 'unit', 'currency')))
    missing = _numbers(text) - allowed
    if missing:
        return 'A number or date is absent from the cited evidence and linked inputs.'
    for entity in _CAMEL.findall(text):
        if entity not in _IGNORE and entity.casefold() not in evidence.casefold():
            return 'A named entity is absent from this clause’s cited evidence.'
    if _CAUSE.search(text) and not (_CAUSE.search(evidence) or _INFERENCE.search(text)):
        return 'A causal interpretation needs cited causal evidence or an explicit inference label.'
    return None

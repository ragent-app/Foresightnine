"""Preserve checkpointed question components and conservatively disclose gaps."""
import re
from collections.abc import Mapping
from typing import Any


def _requested_parts(question: str) -> list[str]:
    # Split enumeration syntax, never individual characters inside ordinary entity names.
    text = question.strip()
    introduced = re.search(r'(?:包括|包含|例如|分别是|include(?:s|d)?\s*:?)\s*', text, re.IGNORECASE)
    if introduced:
        text = text[introduced.end():]
    enumerated = bool(introduced or re.search(r'[、;；?？,，]|\b(?:and|or)\b|以及|并且|(?:^|\s)\d+[.)、]', text, re.IGNORECASE))
    if not enumerated:
        return [text] if text else []
    # 和/及 are only separators within an explicit enumeration and when not embedded
    # inside a contiguous Chinese word; 、/以及 and punctuation remain preferred.
    pattern = r'[、;；?？,，]|\b(?:and|or)\b|以及|并且|(?:^|\s)\d+[.)、]'
    if introduced:
        pattern += r'|(?<=[\u4e00-\u9fff])和(?=[\u4e00-\u9fff])'
    return [p.strip(' \t\n.。:：') for p in re.split(pattern, text, flags=re.IGNORECASE) if p.strip(' \t\n.。:：')]


def question_parts(question: str, state: Mapping[str, Any], eligible_source_ids: set[str]) -> list[dict]:
    facts = {fact.get('fact_id'): fact for key in ('prior_facts', 'facts') for fact in (state.get(key) or []) if isinstance(fact, Mapping)}
    rows = []
    for item in state.get('question_parts') or []:
        if not isinstance(item, Mapping) or not item.get('question') or item['question'] not in question:
            continue
        refs = [ref for ref in item.get('references', []) if isinstance(ref, Mapping)
                and facts.get(ref.get('fact_id'), {}).get('source_id') in eligible_source_ids]
        if len(refs) != len(item.get('references', [])):
            rows.append({'question': item['question'], 'status': 'unresolved', 'answer': '',
                         'reason': '相关依据当前不可用，无法展示已保存的回答。', 'references': []})
        else:
            rows.append(dict(item))
    for part in _requested_parts(question):
        # A saved exact excerpt covers that component; preserve additional uncovered text.
        remaining = part
        for row in rows:
            remaining = remaining.replace(row['question'], '', 1)
        remaining = remaining.strip(' \t\n.。:：')
        if remaining and not any(part == row['question'] for row in rows):
            rows.append({'question': remaining, 'status': 'unresolved', 'answer': '',
                         'reason': '这一部分尚未回答；需要补充相关依据和具体条件。', 'references': []})
    return rows[:21]

"""Read only the topic-scoped private snapshot, and emit aggregate results."""
import argparse
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path

from app.research_context_manager import _record_failed_attempt, build_model_turn_input
from app.research_recovery import prepare_runtime_continuation, runtime_interruption_no_progress_blocked
from app.research_sources import ResearchSource
from app.research_topics import ResearchContent, ResearchTurn
from app.research_turns import merge_turn


def inputs_size(cp, sources):
    msg = build_model_turn_input(state=cp, source_by_id=sources)
    return len(json.dumps(asdict(msg), ensure_ascii=False, separators=(',', ':')).encode())


def replay(directory):
    rows = [json.loads(line) for line in (directory/'history.jsonl').read_text().splitlines()]
    sources = {s.source_id:s for line in (directory/'sources.jsonl').read_text().splitlines()
               if (s := ResearchSource.model_validate_json(line))}
    versions = rows[0]['versions']
    first = rows[2]['checkpoint']
    follow = deepcopy(rows[3]['checkpoint'])
    hashes = {name:sha256((directory/name).read_bytes()).hexdigest() for name in ('history.jsonl','sources.jsonl')}
    initial = inputs_size(follow, sources)
    for index in (3,4):
        failure = rows[index]['checkpoint']['events'][-1]
        diag = rows[index]['diagnostics'][failure['call_id']]
        _record_failed_attempt(follow, call_id=failure['call_id'], reason=failure['code'], call_diag=diag)
        if index == 3:
            follow = prepare_runtime_continuation(follow)
            smaller = inputs_size(follow, sources)
    assert runtime_interruption_no_progress_blocked(follow)
    assert smaller < initial
    # Reconstruct the actual checked submission using the same version merger as the persister.
    content = ResearchContent.model_validate(versions[2]['content'])
    turn = ResearchTurn.model_validate(content.turns[-1])
    table_id = first['tables'][0]['table_id']
    turn.table_ids = [table_id]
    merged = merge_turn(content, turn, facts=[], calculations=[], claims=[], charts=[], sources=[], source_candidates=[],
                        tables=first['tables'])
    reopened = ResearchContent.model_validate_json(merged.model_dump_json())
    assert reopened.tables[0].table_id == table_id
    assert table_id in reopened.turns[-1].report
    assert all(sid in sources for sid in reopened.tables[0].source_ids)
    return dict(input_sha256=hashes, initial_model_input_bytes=initial, resumed_model_input_bytes=smaller,
                repeated_interruption_stopped=True, table_rows=len(reopened.tables[0].rows),
                table_columns=len(reopened.tables[0].columns), full_export_permitted=all(
                    sources[sid].permissions.export for sid in reopened.tables[0].source_ids))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('directory', type=Path)
    print(json.dumps(replay(p.parse_args().directory), indent=2))

"""Version-local review queue derived from recorded research state.

The queue does not establish semantic truth or prove the absence of gaps.
It contains only identifiers and indexes, not source text or new model claims.
"""
from __future__ import annotations

from typing import Any


CLAIM_EVIDENCE_WARNINGS = (
    'counterpoint_relevance_unverified', 'percentage_unit_unverified', 'prior_findings_scope_unverified',
    'source_scope_absence_unverified', 'causal_attribution_unverified', 'uncited_exact_dates',
    'publication_date_warnings', 'rate_unit_warnings', 'uncited_amounts', 'uncited_claim_amounts',
    'uncited_dollar_amounts', 'uncited_quarters', 'balance_direction_warnings', 'uncited_percentages',
    'uncited_percentage_bounds', 'reused_percentages', 'uncited_basis_points',
    'uncited_percentage_points', 'uncited_fact_values', 'citation_context_warnings',
)
MAX_REFS = 50


def incomplete_requested_stages(run: dict[str, Any]) -> list[str]:
    """Return requested stages that lack an acceptable execution outcome.

    Execution completion is not a judgment about the truth of the output.
    Missing state is treated as incomplete only for explicitly requested stages.
    """
    stages = (
        ('planning', 'planning_requested', 'planning_status', {'completed'}),
        ('counterpoint', 'counterpoint_requested', 'counterpoint_status', {'completed', 'not_needed'}),
        ('gap_search', 'gap_search_requested', 'gap_search_status', {'completed', 'no_gaps'}),
        ('gap_followup', 'gap_followup_requested', 'gap_followup_status', {'completed', 'not_needed'}),
        ('support_review', 'support_review_requested', 'support_review_status', {'complete'}),
    )
    return [name for name, requested, status, accepted in stages
            if run.get(requested) is True and
            (not isinstance(run.get(status), str) or run[status] not in accepted)]


def model_review_outcomes(claims: list[dict]) -> dict[str, list[int]]:
    """Group recorded review opinions, including missing or unrecognized reviews.

    These are model opinions about citations, not independent verification.
    """
    outcomes: dict[str, list[int]] = {name: [] for name in
        ('supports', 'does_not_support', 'contradicts', 'uncertain', 'not_reviewed')}
    for index, claim in enumerate(claims):
        review = claim.get('support_review') if isinstance(claim, dict) else None
        verdict = review.get('verdict') if isinstance(review, dict) else None
        outcomes[verdict if isinstance(verdict, str) and verdict in outcomes else 'not_reviewed'].append(index)
    return outcomes


def research_gaps(*, claims: list[dict], calculations: list[dict], sources: list[dict],
                  calculation_differences: list[dict], amount_differences: list[dict],
                  run: dict[str, Any], facts: list[dict] | None = None) -> dict[str, Any]:
    """Build a bounded checklist, without interpreting sources or model prose."""
    items: list[dict[str, Any]] = []
    def add(code: str, indexes: list[int] | None = None, *, kind: str | None = None) -> None:
        entry: dict[str, Any] = {'code': code}
        if indexes is not None:
            entry.update({'indexes': indexes[:MAX_REFS], 'count': len(indexes), 'truncated': len(indexes) > MAX_REFS})
        if kind is not None:
            entry['index_kind'] = kind
        items.append(entry)

    attempted = bool(run.get('operation_id'))
    coverage = run.get('requirement_coverage')
    if isinstance(coverage, dict) and isinstance(coverage.get('requirements'), list):
        requirements = coverage['requirements']
        for gap, code in (('suggested_requirement_without_evidence_link', 'suggested_requirement_unlinked'),
                          ('suggested_calculation_not_linked', 'suggested_calculation_unlinked')):
            indexes = [i for i, item in enumerate(requirements) if isinstance(item, dict)
                       and isinstance(item.get('gaps'), list) and gap in item['gaps']]
            if indexes:
                add(code, indexes, kind='requirement')
    if attempted and not sources:
        add('no_analyzed_sources')
    source_states = run.get('source_processing')
    if isinstance(source_states, list) and any(isinstance(item, dict) and
            (item.get('eligibility') != 'eligible' or item.get('initial_selection') != 'complete') for item in source_states):
        add('source_processing_incomplete')
    scope = run.get('scope_assessment')
    if attempted and isinstance(scope, dict) and scope.get('scope') != 'complete_input_selected':
        add('source_scope_review_required')
    absence = run.get('absence_assessment')
    if isinstance(absence, dict) and absence.get('observations'):
        add('absence_observation_unestablished')
    needs = run.get('evidence_needs')
    if isinstance(needs, dict) and any(isinstance(item, dict) and item.get('evidence_type') == 'model_suggested_material'
                                       for item in needs.get('items', [])):
        add('model_suggested_evidence_need')
    support = [i for i, claim in enumerate(claims) if isinstance(claim, dict) and claim.get('role') != 'counterargument']
    counter = [i for i, claim in enumerate(claims) if isinstance(claim, dict) and claim.get('role') == 'counterargument']
    if attempted and not support:
        add('no_findings')
    missing_dimensions = [i for i, fact in enumerate(facts or []) if isinstance(fact, dict)
                          and any(not isinstance(fact.get(field), str) or not fact[field].strip()
                                  for field in ('unit', 'period'))]
    if missing_dimensions:
        add('fact_unit_or_period_missing', missing_dimensions, kind='fact')
    questions = run.get('research_questions')
    if isinstance(questions, list):
        unlinked_questions = [i for i, item in enumerate(questions) if isinstance(item, dict) and not item.get('claim_ids')]
        if unlinked_questions:
            add('subquestions_unlinked', unlinked_questions, kind='question')
    uncited = [i for i, claim in enumerate(claims) if isinstance(claim, dict) and
               (not isinstance(claim.get('citations'), list) or not claim['citations'] or claim.get('support_status') in {'unsupported', 'incomplete'})]
    if uncited:
        add('citations_missing_or_incomplete', uncited, kind='claim')
    # A location or a model opinion does not establish semantic support.
    # Preserve the review item even when a model reports support.
    if claims:
        add('semantic_support_not_independently_verified',
            [i for i, claim in enumerate(claims) if isinstance(claim, dict)], kind='claim')
    warned = [i for i, claim in enumerate(claims) if isinstance(claim, dict) and
              any(claim.get(name) for name in CLAIM_EVIDENCE_WARNINGS)]
    if warned:
        add('evidence_warnings', warned, kind='claim')
    omitted_fact_links = [i for i, claim in enumerate(claims) if isinstance(claim, dict) and claim.get('user_fact_links_omitted')]
    if omitted_fact_links:
        add('user_fact_links_omitted', omitted_fact_links, kind='claim')
    if support and run.get('require_counterarguments') is True and not counter:
        add('no_counterpoint')
    unlinked = [i for i in counter if not claims[i].get('responds_to_claim_ids') and
                not claims[i].get('suggested_responds_to_claim_ids')]
    if unlinked:
        add('counterpoint_target_unlinked', unlinked, kind='claim')
    unverified_calculations = [i for i, item in enumerate(calculations) if isinstance(item, dict) and item.get('input_status') != 'matched']
    if unverified_calculations:
        add('calculation_inputs_unverified', unverified_calculations, kind='calculation')
    unchecked_results = [i for i, item in enumerate(calculations) if isinstance(item, dict) and item.get('result_status') != 'matched']
    if unchecked_results:
        add('calculation_results_unverified', unchecked_results, kind='calculation')
    if calculation_differences or amount_differences:
        add('calculation_or_amount_differences')
    incomplete = incomplete_requested_stages(run)
    for stage, code in (('planning', 'research_planning_incomplete'),
                        ('gap_search', 'gap_source_search_incomplete'),
                        ('gap_followup', 'gap_followup_incomplete'),
                        ('support_review', 'model_review_incomplete')):
        if stage in incomplete:
            add(code)
    if run.get('support_review_requested') is True:
        outcomes = model_review_outcomes(claims)
        for verdict, code in (('does_not_support', 'model_review_does_not_support'),
                              ('contradicts', 'model_review_contradiction'),
                              ('uncertain', 'model_review_uncertain'),
                              ('not_reviewed', 'model_review_missing')):
            if outcomes[verdict]:
                add(code, outcomes[verdict], kind='claim')
    if run.get('support_review_requested') and run.get('require_counterarguments') is True:
        unreviewed_relation = [i for i in counter if not isinstance(claims[i].get('support_review'), dict) or
                               claims[i]['support_review'].get('relevance') != 'relevant']
        if unreviewed_relation:
            add('counterpoint_relevance_unverified', unreviewed_relation, kind='claim')
    if 'counterpoint' in incomplete:
        add('counterpoint_followup_incomplete')
    if attempted and run.get('status') == 'partial':
        add('last_run_partial')
    return {'schema_version': '1', 'index_scope': 'research_version',
            'meaning': 'recorded_review_cues_not_a_quality_verdict', 'items': items}

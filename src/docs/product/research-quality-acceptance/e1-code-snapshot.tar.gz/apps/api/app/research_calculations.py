"""Auditable deterministic financial calculations for research tools."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from datetime import date, datetime
from hashlib import sha256
import json
import re
from typing import Literal, Sequence

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator


FormulaId = Literal[
    "growth_percent",
    "margin_percent",
    "difference",
    "cagr",
    "ratio",
    "sum",
    "subtract",
    "weighted_average",
    "ttm_sum",
]
BINARY_FORMULAS: frozenset[str] = frozenset({"growth_percent", "margin_percent", "difference", "cagr", "ratio"})
MULTI_FACT_FORMULAS: frozenset[str] = frozenset({"sum", "subtract", "weighted_average", "ttm_sum"})


class NumericFact(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    fact_id: str = Field(min_length=1, max_length=200)
    value: Decimal
    unit: str = Field(min_length=1, max_length=100)
    currency: str | None = Field(default=None, min_length=1, max_length=16)
    period: str = Field(min_length=1, max_length=100)

    @field_validator("value")
    @classmethod
    def finite_reasonable_value(cls, value: Decimal) -> Decimal:
        if not value.is_finite() or len(value.as_tuple().digits) > 30 or abs(value.adjusted()) > 30:
            raise ValueError("Value must be finite and within supported precision.")
        return value


class CalculationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    formula: FormulaId
    first: NumericFact | None = None
    second: NumericFact | None = None
    facts: list[NumericFact] | None = Field(default=None, min_length=2, max_length=50)
    weights: list[Decimal] | None = None
    periods: Decimal | None = None
    decimal_places: int = Field(default=2, ge=0, le=8)

    @field_validator("periods")
    @classmethod
    def validate_periods(cls, value: Decimal | None) -> Decimal | None:
        if value is None:
            return None
        if isinstance(value, bool) or not value.is_finite() or value <= 0 or value > Decimal("1000"):
            raise ValueError("periods must be a finite positive number <= 1000.")
        return value

    @field_validator("weights")
    @classmethod
    def validate_weights(cls, value: list[Decimal] | None) -> list[Decimal] | None:
        if value is None:
            return None
        if not value:
            raise ValueError("weights must not be empty.")
        for item in value:
            if isinstance(item, bool) or not item.is_finite() or item < 0 or abs(item.adjusted()) > 30:
                raise ValueError("weights must be finite non-negative numbers within supported precision.")
        if sum(value, Decimal(0)) <= 0:
            raise ValueError("weights sum must be positive.")
        return value

    @model_validator(mode="after")
    def validate_inputs_and_parameters(self) -> CalculationRequest:
        if self.facts is not None:
            if self.first is not None or self.second is not None:
                raise ValueError("Provide either first/second or facts, not both.")
            resolved = list(self.facts)
        else:
            if self.first is None or self.second is None:
                raise ValueError("Provide first and second facts, or facts list.")
            resolved = [self.first, self.second]

        if self.formula in BINARY_FORMULAS and len(resolved) != 2:
            raise ValueError(f"Formula {self.formula!r} requires exactly 2 facts.")
        if self.formula == "ttm_sum" and len(resolved) != 4:
            raise ValueError("Formula 'ttm_sum' requires exactly 4 quarterly facts.")

        if len(resolved) == 2 and self.first is None and self.second is None:
            self.first = resolved[0]
            self.second = resolved[1]

        if self.formula == "cagr":
            if self.periods is None:
                raise ValueError("periods > 0 is required for formula 'cagr'.")
        elif self.periods is not None:
            raise ValueError("periods is only supported for formula 'cagr'.")

        if self.formula == "weighted_average":
            if self.weights is None:
                raise ValueError("weights are required for formula 'weighted_average'.")
            if len(self.weights) != len(resolved):
                raise ValueError("weights length must match the number of input facts.")
        elif self.weights is not None:
            raise ValueError("weights is only supported for formula 'weighted_average'.")

        return self

    def resolved_facts(self) -> list[NumericFact]:
        if self.facts is not None:
            return list(self.facts)
        assert self.first is not None and self.second is not None
        return [self.first, self.second]


class RecalculateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    parent_version_id: str = Field(min_length=1, max_length=100)
    calculation_index: int = Field(ge=0, le=1999, strict=True)


class CreateResearchCalculationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    parent_version_id: str = Field(min_length=1, max_length=100)
    formula: Literal["growth_percent", "margin_percent", "difference"]
    first_fact_id: str = Field(min_length=1, max_length=200)
    second_fact_id: str = Field(min_length=1, max_length=200)
    decimal_places: int = Field(default=2, ge=0, le=8, strict=True)


class ConfirmDirectionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    parent_version_id: str = Field(min_length=1, max_length=100)
    fact_id: str = Field(min_length=1, max_length=200)


_DIRECTION_FINGERPRINT_FIELDS = ("fact_id", "label", "value", "unit", "currency", "period", "source_id", "quotation", "location")


def direction_confirmation_fingerprint(fact: dict) -> str:
    data = {key: fact.get(key) for key in _DIRECTION_FINGERPRINT_FIELDS}
    return sha256(json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def derive_direction_proof(fact: dict, source_text: str, source_sha256: str,
                           context_start: int, context_end: int) -> dict | None:
    """Derive a narrow direction cue from a uniquely located source sentence.

    This checks a textual conversion, not the source's truth or the economic
    comparability of two facts. Ambiguous syntax and unsupported units fail closed.
    """
    location = fact.get('location')
    if not isinstance(location, dict) or location.get('status') == 'ambiguous':
        return None
    start, end = location.get('character_start'), location.get('character_end')
    quote = fact.get('quotation')
    if (not isinstance(source_text, str) or not isinstance(quote, str) or
            type(start) is not int or type(end) is not int or
            type(context_start) is not int or type(context_end) is not int or
            not 0 <= context_start <= start < end <= context_end <= len(source_text) or
            source_text[start:end] != quote or source_text.count(quote) != 1 or
            sha256(source_text.encode('utf-8')).hexdigest() != source_sha256 or
            not isinstance(fact.get('source_id'), str)):
        return None
    try:
        value = Decimal(str(fact.get('value')))
    except (InvalidOperation, ValueError):
        return None
    if not value.is_finite() or value >= 0 or not is_percent_unit(str(fact.get('unit', ''))) or fact.get('currency') is not None:
        return None
    # A single finite percentage governed directly by an explicit downward
    # verb; reject level targets ('decreased to'), competing numbers and verbs.
    pattern = r'\b(decreased|declined|fell|dropped)\s+(?:by\s+)?(\d+(?:\.\d+)?)\s*(?:percent\b|per\s+cent\b|%(?!\w))'
    matches = list(re.finditer(pattern, quote, re.I))
    if len(matches) != 1 or Decimal(matches[0].group(2)) != -value:
        return None
    if len(re.findall(r'\b(?:decreased|declined|fell|dropped|increased|rose|grew|up|down)\b', quote, re.I)) != 1:
        return None
    if len(re.findall(r'(?<![\w.])\d+(?:\.\d+)?\s*(?:percent|per\s+cent|%)', quote, re.I)) != 1:
        return None
    prefix = quote[:matches[0].start()].strip()
    subject = re.split(r'[,;:\n]', prefix)[-1].strip()
    subject = re.sub(r'^(?:the|a|an)\s+', '', subject, flags=re.I)
    label = str(fact.get('label', '')).casefold()
    if not subject or len(subject) > 80 or not re.fullmatch(r'[\w\s&/-]+', subject) or subject.casefold() not in label:
        return None
    if re.search(r'\b(?:not|never|expected|expectation|forecast|estimated|projected|projection|target|scenario|assuming|assumed|may|might|could|would|if|unless|despite)\b', quote, re.I):
        return None
    # Use the containing paragraph inside the selected unit, never an unrelated
    # year or measure elsewhere in a long source.
    paragraph_start = source_text.rfind('\n\n', context_start, start)
    paragraph_end = source_text.find('\n\n', end, context_end)
    context_start = paragraph_start + 2 if paragraph_start >= 0 else context_start
    context_end = paragraph_end if paragraph_end >= 0 else context_end
    context = source_text[context_start:context_end]
    if len(context) > 1200:
        return None
    if re.search(r'\b(?:not|never|expected|expectation|forecast|estimated|projected|projection|target|scenario|assuming|assumed|may|might|could|would|if|unless|despite)\b', context, re.I):
        return None
    label_remainder = label.replace(subject.casefold(), ' ', 1)
    words = re.findall(r'[a-z]+', label_remainder)
    if any(word not in {'growth', 'change', 'rate', 'quarter', 'annual', 'estimate', 'advance', 'q'} for word in words):
        return None
    if re.search(r'annual', str(fact.get('unit', '')), re.I) and not re.search(r'\bannual(?:ized|ised)?\s+rate\b', context, re.I):
        return None
    period = str(fact.get('period', ''))
    years = set(re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', context))
    period_years = set(re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', period))
    if len(years) != 1 or years != period_years:
        return None
    quarters = {'1': r'(?:q1|first\s+quarter)', '2': r'(?:q2|second\s+quarter)',
                '3': r'(?:q3|third\s+quarter)', '4': r'(?:q4|fourth\s+quarter)'}
    period_quarters = [number for number, expression in quarters.items() if re.search(r'\b' + expression + r'\b', period, re.I)]
    quote_quarters = [number for number, expression in quarters.items() if re.search(r'\b' + expression + r'\b', quote, re.I)]
    if quote_quarters and quote_quarters != period_quarters:
        return None
    if period_quarters and (len(period_quarters) != 1 or not re.search(r'\b' + quarters[period_quarters[0]] + r'\b', quote, re.I)):
        return None
    if not period_quarters and not re.search(r'\b' + next(iter(years)) + r'\b', quote):
        return None
    return {'method': 'source_direction_percent_v1', 'source_id': fact['source_id'],
            'source_sha256': source_sha256, 'context_start': context_start, 'context_end': context_end,
            'context_sha256': sha256(context.encode('utf-8')).hexdigest(),
            'fact_sha256': direction_confirmation_fingerprint(fact), 'direction': 'decrease',
            'subject': subject, 'verification': 'textual_conversion_not_independent_fact_verification'}


def verified_direction_proof(fact: dict) -> bool:
    proof = fact.get('direction_derivation')
    return (isinstance(proof, dict) and proof.get('method') == 'source_direction_percent_v1'
            and proof.get('source_id') == fact.get('source_id')
            and proof.get('fact_sha256') == direction_confirmation_fingerprint(fact)
            and bool(re.fullmatch(r'[0-9a-f]{64}', str(proof.get('source_sha256', ''))))
            and bool(re.fullmatch(r'[0-9a-f]{64}', str(proof.get('context_sha256', '')))))


def direction_user_confirmed(fact: dict) -> bool:
    confirmation = fact.get("direction_confirmation")
    if not isinstance(confirmation, dict) or confirmation.get("confirmed_by") != "user":
        return False
    try:
        return confirmation.get("fact_sha256") == direction_confirmation_fingerprint(fact)
    except (TypeError, ValueError):
        return False


def table_user_confirmed(fact: dict) -> bool:
    confirmation = fact.get("table_confirmation")
    if not isinstance(confirmation, dict) or confirmation.get("confirmed_by") != "user":
        return False
    try:
        return confirmation.get("fact_sha256") == direction_confirmation_fingerprint(fact)
    except (TypeError, ValueError):
        return False


def xbrl_source_consistent(fact: dict) -> bool:
    """Check a server-issued source-tag consistency record for this exact fact.

    This is not an attestation of source authenticity or independent accuracy.
    Client edits are required to discard the record at the API boundary.
    """
    proof = fact.get('xbrl_source_consistency')
    alignment = fact.get('table_structure_alignment')
    if (not isinstance(proof, dict) or proof.get('method') != 'inline_xbrl_source_consistency_v1' or
            not re.fullmatch(r'[0-9a-f]{64}', str(proof.get('source_sha256', ''))) or
            not re.fullmatch(r'\d{10}', str(proof.get('entity_cik', ''))) or
            not re.fullmatch(r'(?:us-gaap|ifrs-full):[A-Za-z][A-Za-z0-9]{0,120}', str(proof.get('concept', ''))) or
            proof.get('currency') != fact.get('currency') or not isinstance(alignment, dict) or alignment.get('status') != 'matched'):
        return False
    try:
        return proof.get('fact_sha256') == direction_confirmation_fingerprint(fact)
    except (TypeError, ValueError):
        return False
class CalculationError(ValueError):
    """The available inputs do not support the requested calculation."""


def is_percent_unit(unit: str) -> bool:
    """Recognize percentage levels, excluding percentage-point differences."""
    normalized = " ".join(unit.strip().casefold().split())
    if re.search(r"\bpoints?\b|百分点", normalized):
        return False
    return bool(re.fullmatch(r"(?:(?:annual|annualized|annualised)\s+)?(?:percent|percentage|%|百分比)(?:\s*\([^()]{1,80}\)|(?:,\s*|\s+)(?:at\s+an?\s+)?(?:seasonally\s+adjusted\s+)?(?:annualized(?:\s+rate)?|annualised(?:\s+rate)?|annual rate))?", normalized))


_MONETARY_FACT_LABEL = re.compile(
    r"\b(?:revenues?|net\s+sales|net\s+income|operating\s+(?:income|profit|loss)|"
    r"gross\s+profit|net\s+profit|cash\s+flow|total\s+assets|total\s+liabilities)\b|"
    r"(?:营业收入|營業收入|营收|營收|净收入|淨收入|净利润|淨利潤|营业利润|營業利潤|现金流|現金流|总资产|總資產)",
    re.IGNORECASE)


def monetary_currency_unspecified(fact: dict) -> bool:
    """Identify clearly monetary labels with no explicit currency field.

    This is a limited cue, not classification of all financial metrics. A
    declared currency itself is not independent verification of the source.
    """
    label, unit, currency = fact.get('label'), fact.get('unit'), fact.get('currency')
    if currency is not None or not isinstance(label, str) or not isinstance(unit, str):
        return False
    if (re.search(r'%|％|percent|percentage|百分点|百分點|百分比|basis\s+points?|\bbps\b|基点|基點', unit, re.IGNORECASE) or
            unit.strip().casefold() in {'ratio', 'multiple', 'times', 'x'}):
        return False
    # Model fact labels commonly use snake_case; underscores are not word
    # boundaries in regex and must not hide an otherwise explicit metric.
    return bool(_MONETARY_FACT_LABEL.search(label[:300].replace('_', ' ')))


def monetary_currency_not_in_quotation(fact: dict) -> bool:
    """Flag a source-backed monetary amount when its cited text omits the currency.

    A matching identifier is only a cue; it does not prove that it describes
    the same value or that table columns, units or source data are correct.
    User-entered facts without a source remain explicitly unverified inputs.
    """
    label, unit, currency = fact.get('label'), fact.get('unit'), fact.get('currency')
    quote, source_id = fact.get('quotation'), fact.get('source_id')
    if (not isinstance(label, str) or not isinstance(unit, str) or not isinstance(currency, str) or not currency.strip() or
            not isinstance(source_id, str) or not source_id or not isinstance(quote, str) or not quote):
        return False
    if table_user_confirmed(fact) or xbrl_source_consistent(fact):
        return False
    # Reuse the same narrow monetary-label classification without guessing a
    # currency from a symbol or from the issuer's geography.
    if not monetary_currency_unspecified({'label':label, 'unit':unit, 'currency':None}):
        return False
    return table_currency_quote_missing(currency, '|' + quote.lstrip())


_MONETARY_SCALE = re.compile(r'\b(?:thousands?|millions?|billions?|trillions?)\b|万亿|萬億|十亿|十億|百万|百萬|千|万|萬|亿|億', re.IGNORECASE)
_SCALE_ALIASES = {'thousands':'thousand','millions':'million','billions':'billion','trillions':'trillion',
                  '萬億':'万亿','十億':'十亿','百萬':'百万','萬':'万','億':'亿'}


def monetary_scale_not_in_quotation(fact: dict) -> bool:
    """Flag an explicit monetary scale absent from a source-backed quotation.

    The narrow lexical check does not establish that a quoted scale belongs
    to the same metric or table column. No scale or unknown spelling is not
    interpreted as evidence of an unscaled amount.
    """
    unit, quote, sid = fact.get('unit'), fact.get('quotation'), fact.get('source_id')
    if not isinstance(unit, str) or not isinstance(quote, str) or not quote or not isinstance(sid, str) or not sid:
        return False
    if table_user_confirmed(fact) or xbrl_source_consistent(fact):
        return False
    if not monetary_currency_unspecified({'label':fact.get('label'), 'unit':unit, 'currency':None}):
        return False
    def scales(text: str) -> set[str]:
        return {_SCALE_ALIASES.get(x.group(0).casefold(), x.group(0).casefold()) for x in _MONETARY_SCALE.finditer(text)}
    declared = scales(unit)
    return bool(declared and not declared.issubset(scales(quote)))


def quotation_is_inside_table_row(source_text: str, start: object, quotation: object) -> bool:
    """Identify a located single-line quotation inside a pipe-delimited row.

    This is a formatting cue, not validation of any table cell or period.
    """
    if (type(start) is not int or not isinstance(quotation, str) or not quotation or
            "\n" in quotation or start < 0 or source_text[start:start + len(quotation)] != quotation):
        return False
    line_start = source_text.rfind("\n", 0, start) + 1
    return source_text[line_start:start].lstrip().startswith("|")


def quotation_is_table_row(source_text: str, start: object, quotation: object) -> bool:
    """Recognize a uniquely located single-line table quotation, including a fragment."""
    if (type(start) is not int or not isinstance(quotation, str) or not quotation or
            "\n" in quotation or start < 0 or source_text[start:start + len(quotation)] != quotation):
        return False
    line_start = source_text.rfind("\n", 0, start) + 1
    line_end = source_text.find("\n", start)
    if line_end < 0:
        line_end = len(source_text)
    row = source_text[line_start:line_end].strip()
    return row.startswith("|") and row.endswith("|") and row.count("|") >= 3



def quotation_is_pdf_layout_row(source_text: str, start: object, quotation: object) -> bool:
    """Identify a possible multi-column row in layout-preserving PDF text.

    A formatting cue only: it cannot establish table boundaries, column
    identity, units or whether the selected value supports the fact.
    """
    if (type(start) is not int or not isinstance(quotation, str) or not quotation or
            len(quotation) > 1000 or start < 0 or source_text[start:start + len(quotation)] != quotation):
        return False
    if "\n" in quotation or "\f" in quotation:
        cursor = start
        for part in quotation.splitlines(keepends=True):
            line = part.rstrip("\r\n\f")
            if line and quotation_is_pdf_layout_row(source_text, cursor, line):
                return True
            cursor += len(part)
        return False
    line_start = max(source_text.rfind("\n", 0, start), source_text.rfind("\f", 0, start)) + 1
    ends = [end for end in (source_text.find("\n", start), source_text.find("\f", start)) if end >= 0]
    line_end = min(ends) if ends else len(source_text)
    line = source_text[line_start:line_end]
    if len(line) > 2000 or start + len(quotation) > line_end:
        return False
    cells = re.split(r"(?: {2,}|\t+)", line.strip())
    amount = re.compile(r"[\$€£¥]?\(?[+−-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\)?%?")
    numeric_cells = [index for index, cell in enumerate(cells) if amount.fullmatch(cell.strip())]
    return len(numeric_cells) >= 2 and any(re.search(r"[A-Za-z\u3400-\u9fff]", cell) for cell in cells[:numeric_cells[0]])

def _spanned_table_period_conflict(source_text: str, start: int, value: Decimal,
                                   period: str) -> dict[str, str] | None:
    """Flag a possible mismatch in a tightly bounded extracted HTML table.

    Span labels are extractor annotations or user-provided text, not proof of
    the original HTML layout. The result is a review cue, never verification.
    """
    year_match = re.fullmatch(r"(?:FY\s*)?((?:19|20)\d{2})", period.strip(), re.IGNORECASE)
    if year_match is None:
        ended = parse_annual_period_end(period)
        declared_year = str(ended.year) if ended is not None else None
    else:
        declared_year = year_match.group(1)
    if declared_year is None:
        return None
    def parse_row(line: str) -> list[tuple[int, int, str]] | None:
        line = line.strip()
        if len(line) > 1000 or not line.startswith("|") or not line.endswith("|"):
            return None
        result = []
        position = 0
        for raw in line[1:-1].split("|"):
            cell = raw.strip()
            marker = re.match(r"^\[colspan=([2-9]|[1-9]\d)\]\s*", cell, re.IGNORECASE)
            span = int(marker.group(1)) if marker else 1
            cell = cell[marker.end():].strip() if marker else cell
            if "[colspan=" in cell.casefold() or "[rowspan=" in cell.casefold():
                return None
            result.append((position, position + span, cell))
            position += span
            if position > 120:
                return None
        return result if len(result) >= 2 else None
    def amount(cell: str) -> Decimal | None:
        if not re.fullmatch(r"[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?", cell):
            return None
        try:
            return Decimal(cell.replace(",", ""))
        except InvalidOperation:
            return None
    def parsed_year(cell: str) -> str | None:
        match = re.fullmatch(r"(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+([0-3]?\d),\s*((?:19|20)\d{2})", cell, re.IGNORECASE)
        if not match:
            return None
        try:
            datetime.strptime(" ".join(cell.split()), "%B %d, %Y")
        except ValueError:
            return None
        return match.group(2)
    line_start = source_text.rfind("\n", 0, start) + 1
    line_end = source_text.find("\n", start)
    if line_end < 0:
        line_end = len(source_text)
    line = source_text[line_start:line_end]
    row = parse_row(line)
    if row is None or "[colspan=" not in line.casefold() or not row[0][2]:
        return None
    positions = [(a, b) for a, b, cell in row[1:] if amount(cell) == value]
    if len(positions) != 1:
        return None
    width = row[-1][1]
    lines = source_text[max(0, line_start - 12000):line_start].splitlines()[-12:]
    for i in range(len(lines) - 1, -1, -1):
        cells = parse_row(lines[i])
        if cells is None or cells[-1][1] != width:
            return None
        years = [(a, b, parsed_year(cell)) for a, b, cell in cells if parsed_year(cell)]
        if len(years) >= 2:
            if any(cell and not parsed_year(cell) and cell.casefold() != "variance" for _, _, cell in cells):
                return None
            selected_years = years
            title_found = False
            for title_line in reversed(lines[max(0, i - 4):i]):
                title_row = parse_row(title_line)
                if title_row is None or title_row[-1][1] != width:
                    break
                content = [cell for _, _, cell in title_row if cell]
                if len(content) == 1 and re.fullmatch(r"years?\s+ended", content[0], re.IGNORECASE):
                    title_found = True
                    break
                # Some financial statements put quarterly and annual
                # columns under separate spanning headings and repeat years.
                # Only inspect the annual group when every nonempty heading
                # is a recognized period and the selected cell lies inside
                # exactly one such group. This is still a warning, not proof
                # that extractor markers reflect the original HTML.
                if content and all(re.fullmatch(r"(?:years?|(?:three|six|nine)\s+months?)\s+ended", cell, re.IGNORECASE) for cell in content):
                    groups = [(a, b, cell) for a, b, cell in title_row if cell]
                    group = [(a, b, cell) for a, b, cell in groups
                             if a <= positions[0][0] and positions[0][1] <= b]
                    if (len(group) != 1 or not re.fullmatch(r"years?\s+ended", group[0][2], re.IGNORECASE) or
                            any(sum(a <= ya and yb <= b for a, b, _ in groups) != 1 for ya, yb, _ in years)):
                        return None
                    selected_years = [(a, b, year) for a, b, year in years
                                      if group[0][0] <= a and b <= group[0][1]]
                    title_found = True
                    break
                if content:
                    break
            if (not title_found or len(selected_years) < 2 or
                    len({year for _, _, year in selected_years}) != len(selected_years)):
                return None
            candidates = [year for a, b, year in selected_years if a <= positions[0][0] and positions[0][1] <= b]
            if len(candidates) == 1 and candidates[0] != declared_year:
                return {"declared_year": declared_year, "column_year": candidates[0]}
            return None
        # Only blank rows, unit labels, or ordinary numeric data rows may
        # intervene between date header and target. Arbitrary text stops us.
        nonempty = [cell for _, _, cell in cells if cell]
        if nonempty and not (len(nonempty) == 1 and re.fullmatch(r"\(in\s+(?:millions?|billions?|thousands?)\)", nonempty[0], re.IGNORECASE)):
            if not cells[0][2] or any(cell and cell not in {"$", "€", "£"} and amount(cell) is None for _, _, cell in cells[1:]):
                return None
    return None


def table_period_conflict(source_text: str, start: object, quotation: object,
                          value: Decimal, period: str) -> dict[str, str] | None:
    """Detect a narrow year/value mismatch in a simple rectangular table.

    This never confirms that a fact is correct: unsupported spans, repeated
    values, unrecognized periods, complex amounts and broken table layout fall
    back to ordinary review. The caller must establish unique source location.
    """
    if not quotation_is_table_row(source_text, start, quotation):
        return None
    clean_quote = re.sub(r"\[(?:colspan|rowspan)=\d+\]", " ", quotation, flags=re.IGNORECASE)
    quoted_values = set()
    for match in re.finditer(r"(?<![\w.])([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)(?![\w.,])", clean_quote):
        try:
            quoted_values.add(Decimal(match.group(1).replace(",", "")))
        except InvalidOperation:
            continue
    if value not in quoted_values:
        return None
    spanned_conflict = _spanned_table_period_conflict(source_text, start, value, period)
    if spanned_conflict is not None:
        return spanned_conflict
    year_match = re.fullmatch(r"(?:FY\s*)?((?:19|20)\d{2})", period.strip(), re.IGNORECASE)
    if not year_match:
        return None
    line_start = source_text.rfind("\n", 0, start) + 1
    line_end = source_text.find("\n", start)
    if line_end < 0:
        line_end = len(source_text)
    def cells(line: str) -> list[str] | None:
        line = line.strip()
        if len(line) > 1000 or not line.startswith("|") or not line.endswith("|") or "[colspan=" in line.casefold() or "[rowspan=" in line.casefold():
            return None
        result = [part.strip() for part in line[1:-1].split("|")]
        return result if 3 <= len(result) <= 12 else None
    def amount(cell: str) -> Decimal | None:
        match = re.fullmatch(r"(?:(?:USD|EUR|GBP)\s+)?([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)(?:\s+(?:USD|EUR|GBP))?", cell, re.IGNORECASE)
        if not match:
            return None
        try:
            return Decimal(match.group(1).replace(",", ""))
        except InvalidOperation:
            return None
    row = cells(source_text[line_start:line_end])
    if row is None or not row[0]:
        return None
    positions = [i for i, cell in enumerate(row[1:], 1) if amount(cell) == value]
    if len(positions) != 1:
        return None
    # A small, contiguous rectangle prevents a header from an unrelated
    # narrative or a differently shaped table being applied to the row.
    prior = source_text[max(0, line_start - 12000):line_start].splitlines()
    for line in reversed(prior[-10:]):
        current = cells(line)
        if current is None or len(current) != len(row):
            return None
        if re.fullmatch(r"(?:fiscal\s+)?years?(?:\s+ended)?", current[0], re.IGNORECASE):
            years = current[1:]
            if (not all(re.fullmatch(r"(?:19|20)\d{2}", year) for year in years) or
                    len(set(years)) != len(years)):
                return None
            column_year, declared_year = years[positions[0] - 1], year_match.group(1)
            if column_year != declared_year:
                return {"declared_year": declared_year, "column_year": column_year}
            return None
        if not current[0] or any(cell and amount(cell) is None for cell in current[1:]):
            return None
    return None


def table_currency_quote_missing(currency: str | None, quotation: str | None) -> bool:
    """Flag a table-row quotation without an explicit currency identifier.

    A code or symbol is only a cue, not verification of the financial fact.
    A bare dollar sign is ambiguous across several currencies.
    """
    if not currency or not isinstance(quotation, str) or not quotation.lstrip().startswith("|"):
        return False
    code = currency.strip().upper()
    if re.search(r"(?<![A-Za-z])" + re.escape(code) + r"(?![A-Za-z])", quotation, re.IGNORECASE):
        return False
    patterns = {"USD": r"US\s*\$|U\.?S\.?\s+dollars?", "EUR": r"€|\beuros?\b",
                "GBP": r"£|\bpounds?\s+sterling\b", "JPY": r"\bJapanese\s+yen\b",
                "KRW": r"₩|\bKorean\s+won\b"}
    return not bool(re.search(patterns.get(code, r"(?!)"), quotation, re.IGNORECASE))



_CURRENCY_NUMBER = re.compile(
    r"(?<![A-Za-z0-9])(?:(?P<before>USD|EUR|GBP|US\s*\$|€|£)\s*(?P<amount1>\d[\d,]*(?:\.\d+)?)|"
    r"(?P<amount2>\d[\d,]*(?:\.\d+)?)\s*(?P<after>USD|EUR|GBP|US\s*\$|€|£))(?![A-Za-z0-9])",
    re.IGNORECASE,
)


def currency_value_conflict(currency: str | None, value: object, quotation: str | None) -> bool:
    """Flag explicit currency cues on the same value; not a semantic verdict.

    Bare dollar/yen signs, unrelated values and multiple conflicting cues are
    deliberately inconclusive. Neither a match nor silence proves the unit.
    """
    code = currency.strip().upper() if isinstance(currency, str) else ""
    if code not in {"USD", "EUR", "GBP"} or not isinstance(quotation, str):
        return False
    value_text = str(value)
    if len(value_text) > 128:
        return False
    try:
        expected = Decimal(value_text)
        if not expected.is_finite():
            return False
    except (InvalidOperation, ValueError):
        return False
    seen: set[str] = set()
    for match in _CURRENCY_NUMBER.finditer(quotation):
        try:
            amount = Decimal((match.group("amount1") or match.group("amount2")).replace(",", ""))
        except InvalidOperation:
            continue
        if amount != expected:
            continue
        cue = (match.group("before") or match.group("after")).upper().replace(" ", "")
        seen.add({"US$": "USD", "€": "EUR", "£": "GBP"}.get(cue, cue))
    return bool(len(seen) == 1 and code not in seen)


def parse_annual_period_end(period: str) -> date | None:
    """Recognize an explicit annual end date and an optional consistent FY label.

    Some issuers label a fiscal year differently from its calendar end year;
    such mixed labels require source-specific interpretation and return None.
    """
    value = period.strip()
    match = re.fullmatch(r"(?:(?:FY\s*((?:19|20)\d{2}))\s*\(\s*)?(?:fiscal\s+)?year\s+ended\s+([A-Za-z]+)\s+(\d{1,2}),?\s+((?:19|20)\d{2})(\s*\))?", value, re.IGNORECASE)
    if not match or bool(match.group(1)) != bool(match.group(5)):
        return None
    months = ("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december")
    try:
        end = date(int(match.group(4)), months.index(match.group(2).casefold()) + 1, int(match.group(3)))
    except ValueError:
        return None
    return end if match.group(1) is None or int(match.group(1)) == end.year else None


def _comparable_period(period: str) -> tuple[str, tuple[int, ...]] | None:
    """Parse only unambiguous matching period formats, without guessing fiscal calendars."""
    value = period.strip()
    if match := re.fullmatch(r"(FY)?((?:19|20)\d{2})", value, re.IGNORECASE):
        return ("fiscal_year" if match.group(1) else "calendar_year", (int(match.group(2)),))
    if match := re.fullmatch(r"((?:19|20)\d{2})[- ]?Q([1-4])", value, re.IGNORECASE):
        return ("calendar_quarter", (int(match.group(1)), int(match.group(2))))
    if match := re.fullmatch(r"((?:19|20)\d{2})-(0[1-9]|1[0-2])", value):
        return ("calendar_month", (int(match.group(1)), int(match.group(2))))
    # Financial filings commonly spell out the end date of each annual period.
    # Keep this distinct from bare dates and FY labels: matching dates alone do
    # not establish that two companies use comparable fiscal calendars.
    if day := parse_annual_period_end(value):
        return ("year_ended_date", (day.year, day.month, day.day))
    if re.fullmatch(r"(?:19|20)\d{2}-\d{2}-\d{2}", value):
        try:
            day = date.fromisoformat(value)
        except ValueError:
            return None
        return ("date", (day.year, day.month, day.day))
    return None


def _period_granularity(period: str) -> str | None:
    """Return only explicit, recognized annual, quarterly or monthly grains.

    A bare date does not establish a reporting duration. Matching grains do
    not establish comparable fiscal calendars or accounting definitions.
    """
    parsed = _comparable_period(period)
    if parsed is None:
        return None
    return {"fiscal_year": "year", "calendar_year": "year", "year_ended_date": "year",
            "calendar_quarter": "quarter", "calendar_month": "month"}.get(parsed[0])


def _growth_granularity_conflict(first: str, second: str) -> bool:
    a, b = _period_granularity(first), _period_granularity(second)
    return a is not None and b is not None and a != b


_TEXT_NUMBER = re.compile(r"(?<![A-Za-z0-9_.])[-−]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?")
_TEXT_PERCENT = re.compile(r"(?<![A-Za-z0-9_.])([-−]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)\s*(?:%|％|percent\b)", re.IGNORECASE)
_RATIO_SCALE_PREFIX = re.compile(r"(?:/|÷)\s*[-−]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s*\)*\s*[×*]\s*$")


def _is_ratio_scale_factor(text: str, match: re.Match[str]) -> bool:
    """Recognize only the explicit conversion factor in a numeric ratio.

    A bare 100% or other percentage still needs review. This does not parse
    arbitrary expressions or establish whether a model's formula is correct.
    """
    try:
        return Decimal(match.group(1).replace(",", "").replace("−", "-")) == 100 and bool(
            _RATIO_SCALE_PREFIX.search(text[:match.start()]))
    except InvalidOperation:
        return False


def _plain_decimal_str(value: Decimal) -> str:
    with localcontext() as ctx:
        ctx.prec = 100
        if value == 0:
            return "0"
        text = format(value, "f")
        if "." in text:
            text = text.rstrip("0").rstrip(".")
        return text or "0"


@dataclass(frozen=True)
class UnitScaleSpec:
    family: str
    currency: str | None
    scale_name: str
    exponent: int
    canonical_unit: str
    is_chinese_yuan: bool = False


_EN_SCALE_TO_SPEC: dict[str, tuple[str, int]] = {
    "one": ("ones", 0),
    "ones": ("ones", 0),
    "1": ("ones", 0),
    "unit": ("ones", 0),
    "units": ("ones", 0),
    "thousand": ("thousands", 3),
    "thousands": ("thousands", 3),
    "k": ("thousands", 3),
    "million": ("millions", 6),
    "millions": ("millions", 6),
    "m": ("millions", 6),
    "mn": ("millions", 6),
    "mm": ("millions", 6),
    "billion": ("billions", 9),
    "billions": ("billions", 9),
    "b": ("billions", 9),
    "bn": ("billions", 9),
    "trillion": ("trillions", 12),
    "trillions": ("trillions", 12),
    "t": ("trillions", 12),
    "tn": ("trillions", 12),
}

_ZH_SCALE_PATTERN = re.compile(
    r"(万亿元|万亿|萬億元|萬億|十亿元|十亿|十億元|十億|百万元|百万|百萬元|百萬|亿元|亿|億元|億|万元|万|萬元|萬|千元|千|元)"
)
_ZH_SCALE_TO_SPEC: dict[str, tuple[str, int, bool]] = {
    "元": ("元", 0, True),
    "千元": ("千元", 3, True),
    "千": ("thousands", 3, False),
    "万元": ("万元", 4, True),
    "萬元": ("万元", 4, True),
    "万": ("万元", 4, False),
    "萬": ("万元", 4, False),
    "百万元": ("百万元", 6, True),
    "百萬元": ("百万元", 6, True),
    "百万": ("millions", 6, False),
    "百萬": ("millions", 6, False),
    "亿元": ("亿元", 8, True),
    "億元": ("亿元", 8, True),
    "亿": ("亿元", 8, False),
    "億": ("亿元", 8, False),
    "十亿元": ("十亿元", 9, True),
    "十億元": ("十亿元", 9, True),
    "十亿": ("billions", 9, False),
    "十億": ("billions", 9, False),
    "万亿元": ("万亿元", 12, True),
    "萬億元": ("万亿元", 12, True),
    "万亿": ("trillions", 12, False),
    "萬億": ("trillions", 12, False),
}

_KNOWN_ISO_CURRENCIES = frozenset({
    "USD", "EUR", "GBP", "JPY", "KRW", "CNY", "RMB", "HKD", "TWD",
    "CHF", "CAD", "AUD", "NZD", "SGD", "INR", "BRL", "MXN", "SEK",
    "NOK", "DKK", "ZAR", "SAR", "AED",
})
_CURRENCY_PHRASES: dict[str, str] = {
    "dollar": "USD",
    "dollars": "USD",
    "us dollar": "USD",
    "us dollars": "USD",
    "us$": "USD",
    "euro": "EUR",
    "euros": "EUR",
    "won": "KRW",
    "korean won": "KRW",
    "yen": "JPY",
    "japanese yen": "JPY",
    "yuan": "CNY",
    "renminbi": "CNY",
    "pound": "GBP",
    "pounds": "GBP",
    "sterling": "GBP",
    "人民币": "CNY",
    "人民幣": "CNY",
    "美元": "USD",
    "美金": "USD",
    "港元": "HKD",
    "港币": "HKD",
    "港幣": "HKD",
    "欧元": "EUR",
    "歐元": "EUR",
    "日元": "JPY",
    "日圆": "JPY",
    "韩元": "KRW",
    "韓元": "KRW",
}


def parse_unit_scale(unit: str, currency: str | None = None) -> UnitScaleSpec:
    """Parse unit + optional currency into a normalized scale/family specification."""
    norm = " ".join(str(unit or "").strip().split())
    if not norm:
        raise CalculationError("Unit must not be empty.")
    norm_curr = currency.strip().upper() if isinstance(currency, str) and currency.strip() else None

    if is_percent_unit(norm):
        if norm_curr is not None:
            raise CalculationError("Percentage inputs cannot have a currency.")
        return UnitScaleSpec("percent", None, "ones", 0, "percent")

    lowered = norm.casefold()
    if re.fullmatch(r"percentage\s+points?|百分点|百分點|\bpp\b", lowered):
        if norm_curr is not None:
            raise CalculationError("Percentage-point inputs cannot have a currency.")
        return UnitScaleSpec("percentage_points", None, "ones", 0, "percentage points")

    if re.fullmatch(r"basis\s+points?|\bbps\b|基点|基點", lowered):
        if norm_curr is not None:
            raise CalculationError("Basis-point inputs cannot have a currency.")
        return UnitScaleSpec("bps", None, "ones", 0, "bps")

    if re.search(r"(?:per\s+share|/\s*shares?\b|每股)", lowered):
        numerator = re.sub(r"(?:per\s+share|/\s*shares?\b|每股)", "", norm, flags=re.I).strip()
        if numerator == '$':
            numerator = 'USD'
        if not numerator:
            numerator = norm_curr or ''
        parsed = parse_unit_scale(numerator, norm_curr)
        if parsed.family != 'monetary' or parsed.currency is None:
            raise CalculationError('Per-share unit must specify a currency.')
        if parsed.exponent != 0:
            raise CalculationError('Scaled per-share units are not supported.')
        return UnitScaleSpec('price_per_share', parsed.currency, parsed.scale_name, parsed.exponent,
                             f'{parsed.canonical_unit} per share')

    # Split out known CJK currency prefixes and CJK scale words before ASCII tokenization.
    spaced = lowered.replace(" of ", " ")
    for zh_curr in ("人民币", "人民幣", "美元", "美金", "港元", "港币", "港幣", "欧元", "歐元", "日元", "日圆", "韩元", "韓元"):
        if zh_curr in spaced:
            spaced = spaced.replace(zh_curr, f" {zh_curr} ")
    spaced = _ZH_SCALE_PATTERN.sub(r" \1 ", spaced)
    tokens = [tok for tok in re.split(r"[\s,/()]+", spaced) if tok]
    if not tokens:
        raise CalculationError(f"Invalid unit {unit!r}.")

    unit_currency: str | None = None
    scale_name: str | None = None
    exponent = 0
    is_yuan = False
    is_shares = False
    unmatched: list[str] = []

    i = 0
    while i < len(tokens):
        two = f"{tokens[i]} {tokens[i + 1]}" if i + 1 < len(tokens) else ""
        if two in _CURRENCY_PHRASES:
            mapped_c = _CURRENCY_PHRASES[two]
            if unit_currency and unit_currency != mapped_c:
                raise CalculationError("Multiple currencies found in unit.")
            unit_currency = mapped_c
            i += 2
            continue
        tok = tokens[i]
        upper_tok = tok.upper()
        if tok in ("share", "shares", "股"):
            is_shares = True
        elif upper_tok in _KNOWN_ISO_CURRENCIES:
            mapped_c = "CNY" if upper_tok == "RMB" else upper_tok
            if unit_currency and unit_currency != mapped_c:
                raise CalculationError("Multiple currencies found in unit.")
            unit_currency = mapped_c
        elif tok in _CURRENCY_PHRASES:
            mapped_c = _CURRENCY_PHRASES[tok]
            if unit_currency and unit_currency != mapped_c:
                raise CalculationError("Multiple currencies found in unit.")
            unit_currency = mapped_c
        elif tok in _EN_SCALE_TO_SPEC:
            s_name, s_exp = _EN_SCALE_TO_SPEC[tok]
            if scale_name is not None and (scale_name, exponent) != (s_name, s_exp):
                raise CalculationError("Multiple scales found in unit.")
            scale_name, exponent = s_name, s_exp
        elif tok in _ZH_SCALE_TO_SPEC:
            s_name, s_exp, s_yuan = _ZH_SCALE_TO_SPEC[tok]
            if scale_name is not None and (scale_name, exponent) != (s_name, s_exp):
                raise CalculationError("Multiple scales found in unit.")
            scale_name, exponent = s_name, s_exp
            is_yuan = is_yuan or s_yuan
        else:
            unmatched.append(tok)
        i += 1

    if not unmatched and is_shares and unit_currency is None:
        resolved_scale = scale_name or "ones"
        canonical = "shares" if resolved_scale == "ones" else f"{resolved_scale} shares"
        return UnitScaleSpec("shares", None, resolved_scale, exponent, canonical)

    if not unmatched and not is_shares and (unit_currency is not None or scale_name is not None):
        norm_curr_canon = "CNY" if norm_curr == "RMB" else norm_curr
        if unit_currency is not None and norm_curr_canon is not None and unit_currency != norm_curr_canon:
            raise CalculationError("Input unit currency conflicts with declared currency.")
        resolved_curr = norm_curr or unit_currency
        resolved_scale = scale_name or ("元" if is_yuan else "ones")
        if is_yuan and resolved_scale in ("元", "千元", "万元", "百万元", "亿元", "十亿元", "万亿元"):
            canonical = f"{resolved_curr} {resolved_scale}" if resolved_curr else resolved_scale
            return UnitScaleSpec("monetary", resolved_curr, resolved_scale, exponent, canonical, is_chinese_yuan=True)
        if resolved_curr is not None:
            canonical = f"{resolved_curr} {resolved_scale}" if resolved_scale != "ones" else resolved_curr
            return UnitScaleSpec("monetary", resolved_curr, resolved_scale, exponent, canonical, is_chinese_yuan=False)
        return UnitScaleSpec("monetary", None, resolved_scale, exponent, resolved_scale, is_chinese_yuan=False)

    return UnitScaleSpec(f"custom:{lowered}", norm_curr, "ones", 0, norm)


def align_facts_scale(
    facts: Sequence[NumericFact],
) -> tuple[list[Decimal], str, str | None, list[dict[str, str]]]:
    """Align same-currency/same-family quantities to the finest common scale.

    Returns ``(aligned_values, target_unit, target_currency, scale_adjustments)``.
    Cross-currency and incompatible unit mismatches fail closed with ``CalculationError``.
    """
    if not facts:
        raise CalculationError("At least one input fact is required.")
    raw_currencies = {f.currency for f in facts}
    if len(raw_currencies) != 1:
        raise CalculationError("Input units and currencies must match.")
    declared_currency = facts[0].currency

    if len({f.unit for f in facts}) == 1:
        # Validate self-consistency even on identical units (e.g., percent with currency fails).
        spec0 = parse_unit_scale(facts[0].unit, declared_currency)
        if spec0.family in ("percent", "percentage_points", "bps") and declared_currency is not None:
            raise CalculationError("Percentage inputs cannot have a currency.")
        return [f.value for f in facts], facts[0].unit, declared_currency, []

    specs = [parse_unit_scale(f.unit, f.currency) for f in facts]
    families = {s.family for s in specs}
    if len(families) != 1:
        raise CalculationError("Input units and currencies must match.")
    family = specs[0].family

    eff_currencies = {s.currency for s in specs}
    if len(eff_currencies) != 1:
        raise CalculationError("Input units and currencies must match.")

    if family not in ("monetary", "shares"):
        if len({s.canonical_unit for s in specs}) != 1:
            raise CalculationError("Input units and currencies must match.")
        return [f.value for f in facts], specs[0].canonical_unit, declared_currency, []

    if declared_currency is None and family == "monetary":
        # Without an explicit currency, never combine Chinese '元' units with non-'元' scales.
        if len({s.is_chinese_yuan for s in specs}) != 1:
            raise CalculationError("Input units and currencies must match.")

    target_exponent = min(s.exponent for s in specs)
    min_specs = [s for s in specs if s.exponent == target_exponent]
    # Prefer the exact unit style of an input already at target_exponent (e.g. '万元', 'USD millions', 'USD').
    preferred_idx = next(i for i, s in enumerate(specs) if s.exponent == target_exponent)
    target_spec = min_specs[0]
    if target_spec.is_chinese_yuan and facts[preferred_idx].unit.strip() in (
        "元", "千元", "万元", "百万元", "亿元", "十亿元", "万亿元"
    ):
        target_unit = facts[preferred_idx].unit.strip()
    elif target_spec.family == "monetary" and declared_currency and facts[preferred_idx].unit.strip() == declared_currency:
        target_unit = declared_currency
    else:
        target_unit = target_spec.canonical_unit

    aligned_values: list[Decimal] = []
    scale_adjustments: list[dict[str, str]] = []
    with localcontext() as ctx:
        ctx.prec = 100
        for fact, spec in zip(facts, specs):
            exp_diff = spec.exponent - target_exponent
            factor = Decimal(1).scaleb(exp_diff)
            aligned_val = fact.value.scaleb(exp_diff) if exp_diff else fact.value
            aligned_values.append(aligned_val)
            if exp_diff != 0 or fact.unit != target_unit:
                scale_adjustments.append({
                    "fact_id": fact.fact_id,
                    "from_unit": fact.unit,
                    "to_unit": target_unit,
                    "from_scale": spec.scale_name,
                    "to_scale": target_spec.scale_name,
                    "multiplier": _plain_decimal_str(factor),
                    "original_value": _plain_decimal_str(fact.value),
                    "aligned_value": _plain_decimal_str(aligned_val),
                })

    return aligned_values, target_unit, declared_currency, scale_adjustments


_TTM_QUARTER_RE = re.compile(
    r"^(?:FY\s*)?((?:19|20)\d{2})\s*[- ]?\s*Q([1-4])$",
    re.IGNORECASE,
)
_TTM_ZH_QUARTER_NUM = {"1": 1, "2": 2, "3": 3, "4": 4, "一": 1, "二": 2, "三": 3, "四": 4}
_TTM_ZH_QUARTER_RE = re.compile(r"^((?:19|20)\d{2})\s*年?\s*第?\s*([1-4一二三四])\s*季(?:度)?$")


def _parse_quarter_index(period: str) -> tuple[bool, int] | None:
    text = period.strip()
    m = _TTM_QUARTER_RE.match(text)
    if m:
        is_fy = text.upper().startswith("FY")
        return is_fy, int(m.group(1)) * 4 + (int(m.group(2)) - 1)
    mz = _TTM_ZH_QUARTER_RE.match(text)
    if mz:
        return False, int(mz.group(1)) * 4 + (_TTM_ZH_QUARTER_NUM[mz.group(2)] - 1)
    return None


def legacy_percentage_difference_unit(calculation: dict) -> bool:
    """Identify old results whose now-recognized rate unit needs recalculation."""
    inputs = calculation.get("inputs")
    return bool(calculation.get("formula_id") == "difference" and isinstance(inputs, list) and len(inputs) == 2 and
                all(isinstance(item, dict) and isinstance(item.get("unit"), str) and is_percent_unit(item["unit"]) for item in inputs) and
                calculation.get("unit") != "percentage points")


def calculation_input_status(calculation: dict, facts: list[dict]) -> str:
    """Check a retained calculation against this version's fact values.

    This verifies consistency, not whether the facts or the result are true.
    Old or user-supplied records with missing structure fail closed.
    """
    if legacy_percentage_difference_unit(calculation):
        return "unverifiable"
    formula = calculation.get("formula_id")
    inputs = calculation.get("inputs")
    if (formula not in BINARY_FORMULAS and formula not in MULTI_FACT_FORMULAS) or not isinstance(inputs, list) or len(inputs) < 2 or any(not isinstance(item, dict) for item in inputs):
        return "unverifiable"
    if formula in BINARY_FORMULAS and len(inputs) != 2:
        return "unverifiable"
    if formula == "ttm_sum" and len(inputs) != 4:
        return "unverifiable"
    fields = ("fact_id", "value", "unit", "currency", "period")
    try:
        expected = [NumericFact.model_validate({key: item[key] for key in fields if key in item}) for item in inputs]
        if len({item.fact_id for item in expected}) != len(expected):
            return "unverifiable"
        by_id: dict[str, list[dict]] = {}
        for item in facts:
            fact_id = item.get("fact_id")
            if isinstance(fact_id, str):
                by_id.setdefault(fact_id, []).append(item)
        for snapshot in expected:
            candidates = by_id.get(snapshot.fact_id, [])
            if len(candidates) != 1:
                return "missing_or_ambiguous"
            if (candidates[0].get("quotation_match") == "pdf_line_hyphen_restored" or
                candidates[0].get("quotation_match") == "table_markup_expanded" and not (table_user_confirmed(candidates[0]) or xbrl_source_consistent(candidates[0])) or
                isinstance(candidates[0].get("table_structure_alignment"), dict) and candidates[0]["table_structure_alignment"].get("status") == "conflict" or
                candidates[0].get("table_period_conflict") or monetary_currency_unspecified(candidates[0]) or monetary_currency_not_in_quotation(candidates[0]) or monetary_scale_not_in_quotation(candidates[0]) or (candidates[0].get("direction_context_unverified") and not (direction_user_confirmed(candidates[0]) or verified_direction_proof(candidates[0]))) or currency_value_conflict(
                    candidates[0].get("currency"), snapshot.value, candidates[0].get("quotation"))):
                return "unverifiable"
            actual = NumericFact.model_validate({key: candidates[0][key] for key in fields if key in candidates[0]})
            if actual != snapshot:
                return "changed"
            if candidates[0].get("source_value_warnings") or candidates[0].get("verification") == "user_edited_value_not_in_quotation":
                return "unverifiable"
        # Structured snapshots carry explicit entity and metric identity.
        # Do not combine mismatched or partially identified contexts merely
        # because the units and numbers happen to match.
        structured = [by_id[item.fact_id][0] for item in expected]
        if any(fact.get('extraction_method') == 'sec_company_concept_row_v1' for fact in structured):
            if not all(fact.get('extraction_method') == 'sec_company_concept_row_v1' and
                       isinstance(fact.get('structured_metadata'), dict) for fact in structured):
                return 'unverifiable'
            contexts = [fact['structured_metadata'] for fact in structured]
            if (not all(isinstance(ctx.get('entity_id'), str) and isinstance(ctx.get('metric_id'), str) for ctx in contexts) or
                    len({ctx['entity_id'] for ctx in contexts}) != 1):
                return 'unverifiable'
            same_metric = len({ctx['metric_id'] for ctx in contexts}) == 1
            if formula in {'growth_percent', 'cagr', 'ttm_sum'} and not same_metric:
                return 'unverifiable'
            try:
                ends = [date.fromisoformat(ctx['period_end']) for ctx in contexts]
                starts = [date.fromisoformat(ctx['period_start']) if ctx.get('period_start') else None for ctx in contexts]
                if len({s is None for s in starts}) != 1:
                    return 'unverifiable'
                same_period = len(set(zip(starts, ends))) == 1
                if formula in {'growth_percent', 'cagr'} and ends[0] <= ends[1]:
                    return 'unverifiable'
                if formula == 'margin_percent' and not same_period:
                    return 'unverifiable'
                if formula == 'difference' and not same_metric and not same_period:
                    return 'unverifiable'
                if formula == 'ttm_sum':
                    if any(s is None for s in starts):
                        return 'unverifiable'
                    sorted_spans = sorted(zip(starts, ends))  # type: ignore[type-var]
                    for idx, (s, e) in enumerate(sorted_spans):
                        days = (e - s).days
                        if not (70 <= days <= 105):
                            return 'unverifiable'
                        if idx > 0 and s <= sorted_spans[idx - 1][1]:
                            return 'unverifiable'
                elif formula in {'growth_percent', 'cagr', 'difference'} and same_metric and not same_period and starts[0] is not None:
                    if not (starts[0] > ends[1] or starts[1] > ends[0]):
                        return 'unverifiable'
                    if abs((ends[0] - starts[0]).days - (ends[1] - starts[1]).days) > 7:
                        return 'unverifiable'
            except (KeyError, TypeError, ValueError):
                return 'unverifiable'
        proofs = [by_id[item.fact_id][0].get('xbrl_source_consistency') if xbrl_source_consistent(by_id[item.fact_id][0]) else None for item in expected]
        if any(proofs):
            if (not all(proofs) or len({p.get('entity_cik') for p in proofs}) != 1 or
                    len({p.get('source_sha256') for p in proofs}) != 1):
                return 'unverifiable'
            if formula in {'growth_percent', 'cagr', 'difference', 'ttm_sum'} and len({p.get('concept') for p in proofs}) != 1:
                return 'unverifiable'
            try:
                periods = [(date.fromisoformat(proof['period_start']), date.fromisoformat(proof['period_end'])) for proof in proofs]
            except (KeyError, ValueError, TypeError):
                return 'unverifiable'
            if formula in {'growth_percent', 'cagr', 'difference'}:
                if (not (periods[0][0] > periods[1][1] or periods[1][0] > periods[0][1]) or
                        abs((periods[0][1] - periods[0][0]).days - (periods[1][1] - periods[1][0]).days) > 7):
                    return 'unverifiable'
            elif formula == 'margin_percent' and periods[0] != periods[1]:
                return 'unverifiable'
            elif formula == 'ttm_sum':
                sorted_spans = sorted(periods)
                for idx, (s, e) in enumerate(sorted_spans):
                    if not (70 <= (e - s).days <= 105):
                        return 'unverifiable'
                    if idx > 0 and s <= sorted_spans[idx - 1][1]:
                        return 'unverifiable'
    except (ValidationError, TypeError, ValueError):
        return "unverifiable"
    return "matched"


def calculate(request: CalculationRequest, *, verified_intraday: bool = False) -> dict:
    """Calculate deterministically using 100-digit Decimal precision.

    Preserve original inputs and reject ambiguous or non-comparable quantities.
    For binary formulas, ``first`` is current/numerator/minuend and ``second`` is
    the baseline/denominator/subtrahend. Supports safe same-currency scale
    alignment while failing closed on cross-currency or incompatible unit mismatches.
    """
    inputs = request.resolved_facts()
    if len({item.fact_id for item in inputs}) != len(inputs):
        raise CalculationError("Inputs must identify distinct facts.")

    aligned_values, aligned_unit, aligned_currency, scale_adjustments = align_facts_scale(inputs)

    period_order_check = "not_checked"
    if request.formula == "margin_percent":
        a, b = inputs[0], inputs[1]
        if a.period != b.period:
            raise CalculationError("Margin inputs must have the same period.")
    if request.formula in {"growth_percent", "cagr"}:
        a, b = inputs[0], inputs[1]
        if a.period == b.period and not (request.formula == "growth_percent" and verified_intraday):
            label = "CAGR" if request.formula == "cagr" else "Growth"
            raise CalculationError(f"{label} inputs must refer to different periods.")
        current, baseline = _comparable_period(a.period), _comparable_period(b.period)
        if current is not None and baseline is not None and current[0] == baseline[0]:
            if current[1] <= baseline[1] and not (request.formula == "growth_percent" and verified_intraday and current[1] == baseline[1]):
                label = "CAGR" if request.formula == "cagr" else "Growth"
                raise CalculationError(f"{label} current period must be later than its baseline.")
            period_order_check = "recognized_formats_only"

    if request.formula == "growth_percent" and aligned_values[1] <= 0:
        raise CalculationError("Growth requires a positive baseline.")
    if request.formula == "margin_percent" and aligned_values[1] <= 0:
        raise CalculationError("Margin requires a positive denominator.")
    if request.formula == "cagr":
        if request.periods is None or request.periods <= 0:
            raise CalculationError("CAGR requires positive periods.")
        if aligned_values[1] <= 0:
            raise CalculationError("CAGR requires a positive baseline.")
        if aligned_values[0] < 0:
            raise CalculationError("CAGR requires a non-negative ending value.")
    if request.formula == "ratio" and aligned_values[1] <= 0:
        raise CalculationError("Ratio requires a positive denominator.")
    if request.formula == "ttm_sum":
        if len(inputs) != 4:
            raise CalculationError("ttm_sum requires exactly 4 quarterly facts.")
        raw_periods = [item.period for item in inputs]
        if len(set(raw_periods)) != 4:
            raise CalculationError("ttm_sum inputs must refer to distinct periods.")
        for p in raw_periods:
            gran = _period_granularity(p)
            if gran in {"year", "month"}:
                raise CalculationError("ttm_sum requires quarterly periods.")
        parsed_quarters = [_parse_quarter_index(p) for p in raw_periods]
        if all(item is not None for item in parsed_quarters):
            fy_flags = {item[0] for item in parsed_quarters if item is not None}
            if len(fy_flags) != 1:
                raise CalculationError("ttm_sum cannot mix fiscal and calendar quarter labels.")
            indices = sorted(item[1] for item in parsed_quarters if item is not None)
            if indices != [indices[0] + i for i in range(4)]:
                raise CalculationError("ttm_sum requires 4 consecutive quarterly periods.")
            period_order_check = "recognized_formats_only"

    formula_version = "1"
    is_pct_input = is_percent_unit(inputs[0].unit)
    try:
        with localcontext() as context:
            context.prec = 100
            if request.formula == "growth_percent":
                result = (aligned_values[0] / aligned_values[1] - 1) * 100
                expression = "(first / second - 1) * 100"
                unit = "percent"
            elif request.formula == "margin_percent":
                result = aligned_values[0] / aligned_values[1] * 100
                expression = "first / second * 100"
                unit = "percent"
            elif request.formula == "difference":
                result = aligned_values[0] - aligned_values[1]
                expression = "first - second"
                if is_pct_input:
                    if inputs[0].currency is not None:
                        raise CalculationError("Percentage inputs cannot have a currency.")
                    unit = "percentage points"
                    formula_version = "2"
                else:
                    unit = aligned_unit
            elif request.formula == "cagr":
                assert request.periods is not None
                result = ((aligned_values[0] / aligned_values[1]) ** (Decimal(1) / request.periods) - 1) * 100
                expression = "((first / second) ** (1 / periods) - 1) * 100"
                unit = "percent"
            elif request.formula == "ratio":
                result = aligned_values[0] / aligned_values[1]
                expression = "first / second"
                unit = "ratio"
            elif request.formula == "sum":
                result = sum(aligned_values, Decimal(0))
                expression = "sum(inputs)"
                unit = "percent" if is_pct_input else aligned_unit
            elif request.formula == "subtract":
                result = aligned_values[0] - sum(aligned_values[1:], Decimal(0))
                expression = "inputs[0] - sum(inputs[1:])"
                unit = "percentage points" if is_pct_input else aligned_unit
            elif request.formula == "weighted_average":
                assert request.weights is not None
                weight_sum = sum(request.weights, Decimal(0))
                if weight_sum <= 0:
                    raise CalculationError("Weighted average requires positive total weight.")
                weighted_total = sum((w * v for w, v in zip(request.weights, aligned_values)), Decimal(0))
                result = weighted_total / weight_sum
                expression = "sum(w_i * x_i) / sum(w_i)"
                unit = "percent" if is_pct_input else aligned_unit
            else:  # ttm_sum
                if is_pct_input:
                    raise CalculationError("ttm_sum cannot sum percentage rates.")
                result = sum(aligned_values, Decimal(0))
                expression = "sum(ttm_quarters)"
                unit = aligned_unit
            rounded = result.quantize(Decimal(1).scaleb(-request.decimal_places), rounding=ROUND_HALF_UP)
    except (InvalidOperation, OverflowError) as error:
        raise CalculationError("Calculation exceeds supported precision.") from error

    out_currency = None if unit in {"percent", "percentage points", "ratio"} else aligned_currency
    output: dict[str, object] = {
        "formula_id": request.formula,
        "formula_version": formula_version,
        "expression": expression,
        "input_verification": "not_verified_by_calculator",
        "input_precision_status": "not_established",
        "inputs": [item.model_dump(mode="json") for item in inputs],
        "value": str(rounded),
        "unit": unit,
        "currency": out_currency,
        "rounding": "half_up",
        "decimal_places": request.decimal_places,
    }
    if request.formula in {"growth_percent", "cagr"}:
        output["period_order_check"] = period_order_check
        output["period_granularity_check"] = (
            "different_labels_verify_stock_or_flow"
            if _growth_granularity_conflict(inputs[0].period, inputs[1].period)
            else "not_established"
        )
    elif request.formula == "ttm_sum":
        output["period_order_check"] = period_order_check
    if request.formula == "cagr" and request.periods is not None:
        output["periods"] = _plain_decimal_str(request.periods)
    if request.formula == "weighted_average" and request.weights is not None:
        output["weights"] = [_plain_decimal_str(w) for w in request.weights]
    if scale_adjustments:
        output["scale_adjustments"] = scale_adjustments
    return output


def calculation_result_status(calculation: dict) -> str:
    """Recompute a saved result without asserting that its inputs are true.

    Older, incomplete and unsupported formula records remain unverifiable.
    This compares the stored formula, output and rounding to the engine; it
    does not certify authorship, source validity or economic interpretation.
    """
    try:
        formula = calculation.get('formula_id')
        inputs = calculation.get('inputs')
        if not isinstance(inputs, list) or len(inputs) < 2 or any(not isinstance(item, dict) for item in inputs):
            return 'unverifiable'
        fields = ('fact_id', 'value', 'unit', 'currency', 'period')
        cleaned_inputs = [{key: item[key] for key in fields if key in item} for item in inputs]
        places = calculation.get('decimal_places')
        if type(places) is not int:
            return 'unverifiable'
        payload: dict[str, object] = {'formula': formula, 'decimal_places': places}
        if formula in BINARY_FORMULAS:
            if len(cleaned_inputs) != 2:
                return 'unverifiable'
            payload['first'] = cleaned_inputs[0]
            payload['second'] = cleaned_inputs[1]
            if formula == 'cagr':
                if calculation.get('periods') is None:
                    return 'unverifiable'
                payload['periods'] = calculation.get('periods')
        else:
            payload['facts'] = cleaned_inputs
            if formula == 'weighted_average':
                if calculation.get('weights') is None:
                    return 'unverifiable'
                payload['weights'] = calculation.get('weights')
        request = CalculationRequest.model_validate(payload)
        expected = calculate(request)
        value = Decimal(str(calculation.get('value')))
        if not value.is_finite():
            return 'unverifiable'
        fields_to_match = ('formula_version', 'expression', 'unit', 'currency', 'rounding')
        if value != Decimal(expected['value']) or any(calculation.get(key) != expected[key] for key in fields_to_match):
            return 'mismatch'
        for optional_key in ('periods', 'weights', 'scale_adjustments'):
            if calculation.get(optional_key) != expected.get(optional_key):
                return 'mismatch'
        return 'matched'
    except (ValidationError, CalculationError, InvalidOperation, TypeError, ValueError, KeyError, OverflowError):
        return 'unverifiable'


def _positive_percentage_describes_decrease(text: str, number_start: int, raw: str) -> bool:
    """Recognize only an immediately stated decrease, not its magnitude or cause."""
    if raw.startswith(("-", "+", "−")):
        return False
    prefix = text[max(0, number_start - 80):number_start]
    cue = re.search(r"(?:减少|減少|下降|下滑|下跌|降低)(?:了)?\s*(?:约|約|大约|大約)?\s*$"
                    r"|\b(?:declined|decreased|fell|dropped)\s+by\s+(?:(?:about|approximately)\s+)?$",
                    prefix, re.IGNORECASE)
    if cue is None:
        return False
    prior = prefix[max(0, cue.start() - 16):cue.start()]
    if re.search(r"未|不|没|沒|無|无|并非|並非|\b(?:not|never|no)\b", prior, re.IGNORECASE):
        return False
    return True


def claim_calculation_differences(claims: list[dict], calculations: list[dict], facts: list[dict]) -> list[dict]:
    """Flag narrow numerical mismatches for review, without asserting entailment.

    Compare claims whose percentages denote the same number and have a uniquely
    matching denominator; inspect each stated precision separately. Ratio
    calculations additionally require a ratio cue or both input values, so an
    unrelated year-on-year percentage is not matched on the denominator alone.
    Recompute the saved calculation from current facts at both its own and the
    claim's stated precision; ignore user-edited, stale or ambiguous calculations.
    """
    by_denominator: dict[Decimal, list[tuple[int, CalculationRequest]]] = {}
    for index, item in enumerate(calculations):
        if (item.get("authorship") == "user" or item.get("formula_version") != "1" or
                item.get("formula_id") not in {"growth_percent", "margin_percent"} or
                item.get("unit") != "percent" or calculation_input_status(item, facts) != "matched"):
            continue
        try:
            inputs = item["inputs"]
            request = CalculationRequest.model_validate({"formula": item["formula_id"], "first": inputs[0],
                "second": inputs[1], "decimal_places": item.get("decimal_places", 2)})
            recomputed = calculate(request)
            if (recomputed.get("period_granularity_check") == "different_labels_verify_stock_or_flow" or
                    Decimal(str(item.get("value"))) != Decimal(recomputed["value"])):
                continue
        except (ValidationError, CalculationError, InvalidOperation, TypeError, ValueError, KeyError, IndexError):
            continue
        by_denominator.setdefault(request.second.value, []).append((index, request))
    differences: list[dict] = []
    for claim_index, claim in enumerate(claims):
        text = claim.get("text")
        if not isinstance(text, str) or len(text) > 3000:
            continue
        percentages = [match for match in _TEXT_PERCENT.finditer(text) if not _is_ratio_scale_factor(text, match)]
        if not percentages or len(percentages) > 20:
            continue
        raw_values = [item.group(1).replace(",", "").replace("−", "-") for item in percentages]
        if any(len(raw) > 40 or ("." in raw and len(raw.rsplit(".", 1)[1]) > 8) for raw in raw_values):
            continue
        try:
            stated_values = {Decimal(raw) for raw in raw_values}
            mentioned = {Decimal(m.group().replace(",", "").replace("−", "-")) for m in _TEXT_NUMBER.finditer(text)}
        except InvalidOperation:
            continue
        if len(stated_values) != 1:
            continue
        ratio_cue = re.search(r"\b(?:margin|ratio|share|proportion|percentage\s+of)\b|利潤率|利润率|毛利率|占比|佔比|比例|比率|占|佔", text, re.IGNORECASE)
        candidates = [entry for value in mentioned for entry in by_denominator.get(value, [])
                      if entry[1].formula != "margin_percent" or ratio_cue or entry[1].first.value in mentioned]
        if len(candidates) != 1:
            continue
        calculation_index, request = candidates[0]
        seen: set[tuple[str, str]] = set()
        for match, raw in zip(percentages, raw_values):
            precision = len(raw.rsplit(".", 1)[1]) if "." in raw else 0
            try:
                expected = calculate(request.model_copy(update={"decimal_places": precision}))["value"]
                if (Decimal(raw) == Decimal(expected) or
                        (request.formula == "growth_percent" and Decimal(raw) > 0 and
                         -Decimal(raw) == Decimal(expected) and
                         _positive_percentage_describes_decrease(text, match.start(1), raw)) or
                        (raw, expected) in seen):
                    continue
            except (CalculationError, InvalidOperation):
                continue
            seen.add((raw, expected))
            differences.append({"claim_index": claim_index, "calculation_index": calculation_index,
                                "claimed_value": raw, "calculated_value": expected,
                                "unit": "percent", "status": "requires_review"})
            if len(differences) == 50:
                return differences
    return differences


def suggest_percentage_calculations(claims: list[dict], calculations: list[dict], facts: list[dict]) -> list[dict]:
    """Suggest source-covered calculations; matching is not semantic verification.

    Only reproducible machine calculations with uniquely identified, unedited
    facts whose original passages are covered by the claim's citations qualify.
    Percentages remain uncited and still require review.
    """
    from copy import deepcopy

    facts_by_id: dict[str, list[dict]] = {}
    for fact in facts:
        if isinstance(fact.get("fact_id"), str):
            facts_by_id.setdefault(fact["fact_id"], []).append(fact)
    valid: list[tuple[int, CalculationRequest, list[dict]]] = []
    for index, item in enumerate(calculations):
        if (item.get("authorship") == "user" or item.get("formula_version") != "1" or
                item.get("formula_id") not in {"growth_percent", "margin_percent"} or
                item.get("unit") != "percent" or calculation_input_status(item, facts) != "matched"):
            continue
        try:
            inputs = item["inputs"]
            request = CalculationRequest.model_validate({"formula": item["formula_id"], "first": inputs[0],
                "second": inputs[1], "decimal_places": item.get("decimal_places", 2)})
            recomputed = calculate(request)
            if (recomputed.get("period_granularity_check") == "different_labels_verify_stock_or_flow" or
                    Decimal(str(item.get("value"))) != Decimal(recomputed["value"])):
                continue
            source_facts = [facts_by_id[fact.fact_id][0] for fact in (request.first, request.second)]
        except (ValidationError, CalculationError, InvalidOperation, TypeError, ValueError, KeyError, IndexError):
            continue
        if any(fact.get("verification") != "model_extraction_not_independently_verified" or
               fact.get("authorship") == "user" or not isinstance(fact.get("source_id"), str) or
               not isinstance(fact.get("quotation"), str) or not fact.get("quotation") or
               not isinstance(fact.get("location"), dict) or fact["location"].get("status") == "ambiguous" or
               type(fact["location"].get("character_start")) is not int or
               type(fact["location"].get("character_end")) is not int or
               fact["location"]["character_end"] - fact["location"]["character_start"] != len(fact["quotation"])
               for fact in source_facts):
            continue
        valid.append((index, request, source_facts))
    # Index rounded values once so a large saved version does not repeatedly
    # recompute every calculation for every claim.
    by_result: dict[tuple[int, Decimal], list[tuple[int, CalculationRequest, list[dict]]]] = {}
    for index, request, source_facts in valid:
        for precision in range(9):
            try:
                value = Decimal(calculate(request.model_copy(update={"decimal_places": precision}))["value"])
            except (CalculationError, InvalidOperation):
                continue
            by_result.setdefault((precision, value), []).append((index, request, source_facts))
    output = []
    for claim in claims:
        entry = deepcopy(claim)
        entry.pop("suggested_calculations", None)
        citations = entry.get("citations")
        percentages = entry.get("uncited_percentages")
        if not isinstance(citations, list) or not isinstance(percentages, list):
            output.append(entry)
            continue
        candidates = []
        for raw in percentages[:5]:
            match = _TEXT_PERCENT.fullmatch(raw) if isinstance(raw, str) else None
            if match is None:
                continue
            value = match.group(1).replace(",", "").replace("−", "-")
            precision = len(value.rsplit(".", 1)[1]) if "." in value else 0
            if len(value) > 40 or precision > 8:
                continue
            try:
                stated = Decimal(value)
                matching = by_result.get((precision, stated), [])
                text = entry.get("text")
                if (not matching and stated > 0 and isinstance(text, str) and text.count(raw) == 1 and
                        _positive_percentage_describes_decrease(text, text.index(raw) + match.start(1), value)):
                    matching = [item for item in by_result.get((precision, -stated), []) if item[1].formula == "growth_percent"]
            except InvalidOperation:
                continue
            for index, request, source_facts in matching:
                if not all(any(isinstance(citation, dict) and not citation.get("partial_token") and
                    citation.get("source_id") == fact["source_id"] and isinstance(citation.get("location"), dict) and
                    citation["location"].get("status") != "ambiguous" and
                    type(citation["location"].get("character_start")) is int and
                    type(citation["location"].get("character_end")) is int and
                    citation["location"]["character_start"] <= fact["location"]["character_start"] and
                    citation["location"]["character_end"] >= fact["location"]["character_end"]
                    for citation in citations) for fact in source_facts):
                    continue
                candidates.append({"calculation_index": index, "claimed_percentage": raw,
                    "formula_id": request.formula, "input_fact_ids": [request.first.fact_id, request.second.fact_id],
                    "status": "requires_semantic_review"})
                if len(candidates) >= 5:
                    break
            if len(candidates) >= 5:
                break
        if candidates:
            entry["suggested_calculations"] = candidates
        output.append(entry)
    return output

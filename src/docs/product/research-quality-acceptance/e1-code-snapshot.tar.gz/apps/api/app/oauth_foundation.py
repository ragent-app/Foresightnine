"""Secret-free OAuth configuration and PKCE transaction primitives.

This module deliberately does not make HTTP requests or expose OAuth endpoints.  It
validates server configuration and keeps short-lived authorization transactions in
the configured server-side repository, with an in-memory development fallback.
"""

from __future__ import annotations

import base64
import json
import os
import secrets
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from types import MappingProxyType
from typing import Any, Callable, Literal, Mapping, cast
from urllib.parse import urlsplit

from .storage import (
    JsonDocumentRepository,
    StorageConfig,
    StorageConfigurationError,
    StorageMode,
    StorageRuntimeError,
    build_repository,
)


OAuthProvider = Literal["google", "github"]
SUPPORTED_PROVIDERS: tuple[OAuthProvider, ...] = ("google", "github")

ENV_CALLBACK_BASE_URL = "FORESIGHTNINE_OAUTH_CALLBACK_BASE_URL"
ENV_RETURN_URI_ALLOWLIST = "FORESIGHTNINE_OAUTH_RETURN_URI_ALLOWLIST"
# Optional per-provider redirect URIs for consoles that register a distinct
# callback path per provider (for example app.example.com/api/auth/callback/google).
# When unset, the shared ENV_CALLBACK_BASE_URL is used for that provider.
ENV_PROVIDER_CALLBACK_URL = {
    "google": "FORESIGHTNINE_OAUTH_GOOGLE_CALLBACK_URL",
    "github": "FORESIGHTNINE_OAUTH_GITHUB_CALLBACK_URL",
}
ENV_CLIENT_ID = {
    "google": "FORESIGHTNINE_OAUTH_GOOGLE_CLIENT_ID",
    "github": "FORESIGHTNINE_OAUTH_GITHUB_CLIENT_ID",
}
ENV_CLIENT_SECRET = {
    "google": "FORESIGHTNINE_OAUTH_GOOGLE_CLIENT_SECRET",
    "github": "FORESIGHTNINE_OAUTH_GITHUB_CLIENT_SECRET",
}

DEFAULT_TRANSACTION_TTL_SECONDS = 300
MAX_TRANSACTION_TTL_SECONDS = 600
DEFAULT_EXCHANGE_TICKET_TTL_SECONDS = 90
MAX_EXCHANGE_TICKET_TTL_SECONDS = 300
PKCE_METHOD = "S256"


class OAuthConfigurationError(ValueError):
    """Raised when OAuth is not configured safely enough to be enabled."""


class OAuthTransactionError(ValueError):
    """Raised when a PKCE transaction is invalid, expired, or already consumed."""


class OAuthExchangeTicketError(ValueError):
    """Raised when a one-time OAuth exchange ticket is invalid or unavailable."""


@dataclass(frozen=True, slots=True)
class _PersistentOAuthRecord:
    """Repository value with a database-visible expiry and no raw state key."""

    kind: Literal["transaction", "exchange_ticket"]
    provider: OAuthProvider
    return_uri: str
    created_at: float
    expires_at: datetime
    consumed: bool = False
    client_id: str | None = None
    redirect_uri: str | None = None
    state_digest: str | None = None
    nonce: str | None = None
    code_verifier: str | None = None
    code_challenge: str | None = None
    account_id: str | None = None

    @classmethod
    def for_transaction(cls, transaction: _StoredTransaction) -> _PersistentOAuthRecord:
        return cls(
            kind="transaction",
            provider=transaction.provider,
            return_uri=transaction.return_uri,
            created_at=transaction.created_at,
            expires_at=_utc_datetime(transaction.expires_at),
            client_id=transaction.client_id,
            redirect_uri=transaction.redirect_uri,
            state_digest=sha256(transaction.state.encode("ascii")).hexdigest(),
            nonce=transaction.nonce,
            code_verifier=transaction.code_verifier,
            code_challenge=transaction.code_challenge,
        )

    @classmethod
    def for_exchange_ticket(cls, ticket: _StoredExchangeTicket) -> _PersistentOAuthRecord:
        return cls(
            kind="exchange_ticket",
            provider=ticket.provider,
            return_uri=ticket.return_uri,
            created_at=ticket.created_at,
            expires_at=_utc_datetime(ticket.expires_at),
            account_id=ticket.account_id,
        )

    def consumed_copy(self) -> _PersistentOAuthRecord:
        return _PersistentOAuthRecord(
            kind=self.kind,
            provider=self.provider,
            return_uri=self.return_uri,
            created_at=self.created_at,
            expires_at=self.expires_at,
            consumed=True,
            # A replay tombstone retains no PKCE or identity material after
            # the successful atomic consume.
            client_id=None,
            redirect_uri=None,
            state_digest=None,
            nonce=None,
            code_verifier=None,
            code_challenge=None,
            account_id=None,
        )

    def to_document(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "provider": self.provider,
            "return_uri": self.return_uri,
            "created_at": self.created_at,
            "expires_at": self.expires_at.isoformat(),
            "consumed": self.consumed,
            **({"client_id": self.client_id} if self.client_id is not None else {}),
            **({"redirect_uri": self.redirect_uri} if self.redirect_uri is not None else {}),
            **({"state_digest": self.state_digest} if self.state_digest is not None else {}),
            **({"nonce": self.nonce} if self.nonce is not None else {}),
            **({"code_verifier": self.code_verifier} if self.code_verifier is not None else {}),
            **({"code_challenge": self.code_challenge} if self.code_challenge is not None else {}),
            **({"account_id": self.account_id} if self.account_id is not None else {}),
        }

    @classmethod
    def from_document(cls, value: Any) -> _PersistentOAuthRecord:
        if not isinstance(value, Mapping):
            raise ValueError("OAuth record is malformed")
        kind = value.get("kind")
        provider = value.get("provider")
        if kind not in {"transaction", "exchange_ticket"} or provider not in SUPPORTED_PROVIDERS:
            raise ValueError("OAuth record is malformed")
        expires_at = value.get("expires_at")
        if not isinstance(expires_at, str):
            raise ValueError("OAuth record is malformed")
        try:
            expires = datetime.fromisoformat(expires_at)
        except ValueError as error:
            raise ValueError("OAuth record is malformed") from error
        if expires.tzinfo is None:
            raise ValueError("OAuth record is malformed")
        strings = {name: value.get(name) for name in ("return_uri", "client_id", "redirect_uri", "state_digest", "nonce", "code_verifier", "code_challenge", "account_id")}
        if not isinstance(strings["return_uri"], str) or not isinstance(value.get("created_at"), (int, float)):
            raise ValueError("OAuth record is malformed")
        if not isinstance(value.get("consumed"), bool):
            raise ValueError("OAuth record is malformed")
        if any(item is not None and not isinstance(item, str) for item in strings.values()):
            raise ValueError("OAuth record is malformed")
        if not value["consumed"] and kind == "transaction" and any(strings[name] is None for name in ("client_id", "redirect_uri", "state_digest", "nonce", "code_verifier", "code_challenge")):
            raise ValueError("OAuth record is malformed")
        if not value["consumed"] and kind == "exchange_ticket" and strings["account_id"] is None:
            raise ValueError("OAuth record is malformed")
        return cls(
            kind=cast(Literal["transaction", "exchange_ticket"], kind),
            provider=cast(OAuthProvider, provider),
            return_uri=strings["return_uri"],
            created_at=float(value["created_at"]),
            expires_at=expires,
            consumed=value["consumed"],
            client_id=strings["client_id"],
            redirect_uri=strings["redirect_uri"],
            state_digest=strings["state_digest"],
            nonce=strings["nonce"],
            code_verifier=strings["code_verifier"],
            code_challenge=strings["code_challenge"],
            account_id=strings["account_id"],
        )


def _utc_datetime(timestamp: float) -> datetime:
    return datetime.fromtimestamp(timestamp, timezone.utc)


def _persistent_record_dumper(value: _PersistentOAuthRecord) -> dict[str, Any]:
    if not isinstance(value, _PersistentOAuthRecord):
        raise ValueError("OAuth record is malformed")
    return value.to_document()


def _persistent_record_loader(value: Any) -> _PersistentOAuthRecord:
    return _PersistentOAuthRecord.from_document(value)


def pkce_s256_challenge(code_verifier: str) -> str:
    """Return the RFC 7636 S256 challenge for a code verifier."""

    if not isinstance(code_verifier, str) or not 43 <= len(code_verifier) <= 128:
        raise ValueError("invalid PKCE verifier")
    try:
        code_verifier.encode("ascii")
    except UnicodeEncodeError as exc:
        raise ValueError("invalid PKCE verifier") from exc
    digest = sha256(code_verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def _require_nonempty(value: str | None, *, error: str) -> str:
    if not isinstance(value, str) or not value:
        raise OAuthConfigurationError(error)
    return value


def _has_control_character(value: str) -> bool:
    return any(
        ord(character) < 0x20
        or ord(character) == 0x7F
        or character == "\\"
        or character.isspace()
        for character in value
    )


def _validate_url_parts(value: str, *, deep_link: bool) -> None:
    if _has_control_character(value):
        raise OAuthConfigurationError("OAuth URI contains invalid characters")
    try:
        parts = urlsplit(value)
        # Accessing port forces validation of malformed numeric ports.
        _ = parts.port
    except ValueError as exc:
        raise OAuthConfigurationError("OAuth URI is invalid") from exc

    if parts.username is not None or parts.password is not None:
        raise OAuthConfigurationError("OAuth URI userinfo is not allowed")
    if parts.fragment:
        raise OAuthConfigurationError("OAuth URI fragments are not allowed")

    if deep_link:
        if parts.scheme != "foresightnine" or not parts.netloc:
            raise OAuthConfigurationError("OAuth return URI must be an allowed deep link")
        return

    if parts.scheme != "https" or not parts.hostname:
        raise OAuthConfigurationError("OAuth URI must use HTTPS")


def _validate_callback_base_url(value: str) -> str:
    value = _require_nonempty(value, error="OAuth callback configuration is missing")
    _validate_url_parts(value, deep_link=False)
    try:
        parts = urlsplit(value)
    except ValueError as exc:  # Defensive: the URL was already parsed above.
        raise OAuthConfigurationError("OAuth callback configuration is invalid") from exc
    if parts.query:
        raise OAuthConfigurationError("OAuth callback must not contain a query")
    return value


def _validate_return_uri(value: str) -> str:
    value = _require_nonempty(value, error="OAuth return URI is missing")
    try:
        parts = urlsplit(value)
    except ValueError as exc:
        raise OAuthConfigurationError("OAuth return URI is invalid") from exc
    _validate_url_parts(value, deep_link=parts.scheme == "foresightnine")
    return value


def _parse_return_uri_allowlist(raw: str | None) -> frozenset[str]:
    raw = _require_nonempty(raw, error="OAuth return URI allowlist is missing")
    values: object
    if raw.lstrip().startswith("["):
        try:
            values = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise OAuthConfigurationError("OAuth return URI allowlist is invalid") from exc
        if not isinstance(values, list) or not all(isinstance(value, str) for value in values):
            raise OAuthConfigurationError("OAuth return URI allowlist is invalid")
        candidates = [value.strip() for value in values]
    else:
        candidates = [value.strip() for value in raw.split(",")]

    if not candidates or any(not value for value in candidates):
        raise OAuthConfigurationError("OAuth return URI allowlist is invalid")
    validated = tuple(_validate_return_uri(value) for value in candidates)
    if len(set(validated)) != len(validated):
        raise OAuthConfigurationError("OAuth return URI allowlist contains duplicates")
    return frozenset(validated)


@dataclass(frozen=True, repr=False)
class OAuthProviderConfig:
    """One provider's server-only credentials and public client identifier."""

    provider: OAuthProvider
    client_id: str
    client_secret: str = ""
    callback_url: str | None = None

    def __post_init__(self) -> None:
        if self.provider not in SUPPORTED_PROVIDERS:
            raise OAuthConfigurationError("OAuth provider is not supported")
        if not isinstance(self.client_id, str) or not self.client_id.strip():
            raise OAuthConfigurationError("OAuth client ID is missing")
        if not isinstance(self.client_secret, str) or not self.client_secret:
            raise OAuthConfigurationError("OAuth client secret is missing")
        if self.callback_url is not None:
            _validate_callback_base_url(self.callback_url)

    def __repr__(self) -> str:
        return (
            "OAuthProviderConfig("
            f"provider={self.provider!r}, client_id=<configured>, "
            "client_secret=<redacted>, callback_url=<configured>)"
        )


@dataclass(frozen=True, repr=False)
class OAuthConfiguration:
    """Validated OAuth configuration; secrets remain server-side and redacted."""

    callback_base_url: str
    return_uri_allowlist: frozenset[str]
    providers: Mapping[OAuthProvider, OAuthProviderConfig]

    def __post_init__(self) -> None:
        _validate_callback_base_url(self.callback_base_url)
        allowlist = frozenset(self.return_uri_allowlist)
        if not allowlist:
            raise OAuthConfigurationError("OAuth return URI allowlist is missing")
        for return_uri in allowlist:
            _validate_return_uri(return_uri)
        providers = dict(self.providers)
        if not providers:
            raise OAuthConfigurationError("No OAuth provider is configured")
        if any(
            provider not in SUPPORTED_PROVIDERS
            or not isinstance(provider_config, OAuthProviderConfig)
            or provider_config.provider != provider
            for provider, provider_config in providers.items()
        ):
            raise OAuthConfigurationError("OAuth provider is not supported")
        object.__setattr__(self, "return_uri_allowlist", allowlist)
        object.__setattr__(self, "providers", MappingProxyType(providers))

    def provider_config(self, provider: str) -> OAuthProviderConfig:
        if provider not in SUPPORTED_PROVIDERS:
            raise OAuthTransactionError("OAuth provider is not supported")
        configured = self.providers.get(provider)
        if configured is None:
            raise OAuthConfigurationError("OAuth provider is not configured")
        return configured

    def callback_url_for(self, provider: str) -> str:
        """The exact redirect URI registered in this provider's console."""

        configured = self.provider_config(provider)
        return configured.callback_url or self.callback_base_url

    def __repr__(self) -> str:
        providers = tuple(sorted(self.providers))
        return (
            "OAuthConfiguration("
            f"callback_base_url={self.callback_base_url!r}, "
            f"return_uri_count={len(self.return_uri_allowlist)}, "
            f"providers={providers!r})"
        )


@dataclass(frozen=True)
class OAuthAuthorizationRequest:
    """Safe-to-use fields for a future provider authorization redirect."""

    provider: OAuthProvider
    client_id: str
    redirect_uri: str
    return_uri: str
    state: str
    code_challenge: str
    code_challenge_method: str = PKCE_METHOD


@dataclass(frozen=True, repr=False)
class OAuthTransaction:
    """A consumed transaction, including values needed by a future token exchange."""

    provider: OAuthProvider
    client_id: str
    redirect_uri: str
    return_uri: str
    state: str
    nonce: str
    code_verifier: str
    code_challenge: str
    created_at: float
    expires_at: float

    def __repr__(self) -> str:
        return (
            "OAuthTransaction("
            f"provider={self.provider!r}, client_id=<configured>, "
            f"redirect_uri={self.redirect_uri!r}, return_uri={self.return_uri!r}, "
            "state=<redacted>, nonce=<redacted>, code_verifier=<redacted>, "
            f"code_challenge={self.code_challenge!r}, created_at={self.created_at!r}, "
            f"expires_at={self.expires_at!r})"
        )


@dataclass(frozen=True, repr=False)
class OAuthExchangeTicket:
    """Server-only ticket payload; the opaque ticket itself is never retained."""

    provider: OAuthProvider
    account_id: str
    return_uri: str
    created_at: float
    expires_at: float

    def __repr__(self) -> str:
        return (
            "OAuthExchangeTicket("
            f"provider={self.provider!r}, account_id=<redacted>, "
            f"return_uri={self.return_uri!r}, created_at={self.created_at!r}, "
            f"expires_at={self.expires_at!r})"
        )


@dataclass(frozen=True, repr=False)
class _StoredExchangeTicket:
    provider: OAuthProvider
    account_id: str
    return_uri: str
    created_at: float
    expires_at: float

    def consumed(self) -> OAuthExchangeTicket:
        return OAuthExchangeTicket(
            provider=self.provider,
            account_id=self.account_id,
            return_uri=self.return_uri,
            created_at=self.created_at,
            expires_at=self.expires_at,
        )

    def __repr__(self) -> str:
        return "_StoredExchangeTicket(provider=<configured>, account_id=<redacted>)"


@dataclass(frozen=True, repr=False)
class _StoredTransaction:
    provider: OAuthProvider
    client_id: str
    redirect_uri: str
    return_uri: str
    state: str
    nonce: str
    code_verifier: str
    code_challenge: str
    created_at: float
    expires_at: float

    def consumed(self) -> OAuthTransaction:
        return OAuthTransaction(
            provider=self.provider,
            client_id=self.client_id,
            redirect_uri=self.redirect_uri,
            return_uri=self.return_uri,
            state=self.state,
            nonce=self.nonce,
            code_verifier=self.code_verifier,
            code_challenge=self.code_challenge,
            created_at=self.created_at,
            expires_at=self.expires_at,
        )

    def __repr__(self) -> str:
        return "_StoredTransaction(provider=<configured>, state=<redacted>, secrets=<redacted>)"


def _environment_configuration(environ: Mapping[str, str]) -> OAuthConfiguration:
    callback_base_url = _validate_callback_base_url(environ.get(ENV_CALLBACK_BASE_URL))
    allowlist = _parse_return_uri_allowlist(environ.get(ENV_RETURN_URI_ALLOWLIST))
    providers: dict[OAuthProvider, OAuthProviderConfig] = {}

    for provider in SUPPORTED_PROVIDERS:
        client_id = environ.get(ENV_CLIENT_ID[provider])
        client_secret = environ.get(ENV_CLIENT_SECRET[provider])
        if client_id is None and client_secret is None:
            continue
        if client_id is None or client_secret is None:
            raise OAuthConfigurationError("OAuth provider configuration is incomplete")
        provider_callback = environ.get(ENV_PROVIDER_CALLBACK_URL[provider])
        providers[provider] = OAuthProviderConfig(
            provider=provider,
            client_id=client_id,
            client_secret=client_secret,
            **({"callback_url": provider_callback.strip()} if provider_callback and provider_callback.strip() else {}),
        )

    return OAuthConfiguration(
        callback_base_url=callback_base_url,
        return_uri_allowlist=allowlist,
        providers=providers,
    )


def _storage_environment(environ: Mapping[str, str]) -> dict[str, str]:
    """Apply the same server-side PostgreSQL URL aliases as the API bootstrap."""

    normalized = dict(environ)
    if not normalized.get("FORESIGHTNINE_POSTGRES_DSN", "").strip():
        for name in ("FORESIGHTNINE_POSTGRES_URL", "DATABASE_URL"):
            configured_url = normalized.get(name)
            if configured_url and configured_url.strip():
                normalized["FORESIGHTNINE_POSTGRES_DSN"] = configured_url
                break
    return normalized


def _build_persistent_repository(environ: Mapping[str, str]) -> JsonDocumentRepository[_PersistentOAuthRecord] | None:
    """Use the existing storage selection and fail closed if PostgreSQL is unavailable."""

    try:
        storage = StorageConfig.from_env(_storage_environment(environ))
        if storage.mode is StorageMode.MEMORY:
            return None
        repository = build_repository(
            storage,
            "oauth_foundation",
            value_loader=_persistent_record_loader,
            value_dumper=_persistent_record_dumper,
        )
        check_ready = getattr(repository, "check_ready", None)
        if not callable(check_ready):
            raise StorageRuntimeError("Persistent OAuth storage does not expose a readiness check.")
        check_ready()
        return repository
    except (StorageConfigurationError, StorageRuntimeError, OSError) as error:
        raise OAuthConfigurationError("OAuth persistence is unavailable") from error


class OAuthFoundation:
    """Pure server-side OAuth setup and one-use PKCE transaction storage."""

    def __init__(
        self,
        configuration: OAuthConfiguration,
        *,
        transaction_ttl_seconds: int = DEFAULT_TRANSACTION_TTL_SECONDS,
        clock: Callable[[], float] = time.time,
        repository: JsonDocumentRepository[_PersistentOAuthRecord] | None = None,
    ) -> None:
        if not isinstance(configuration, OAuthConfiguration):
            raise TypeError("configuration must be OAuthConfiguration")
        if not 1 <= transaction_ttl_seconds <= MAX_TRANSACTION_TTL_SECONDS:
            raise ValueError("OAuth transaction TTL is outside the allowed range")
        self._configuration = configuration
        self._transaction_ttl_seconds = transaction_ttl_seconds
        self._clock = clock
        self._transactions: dict[str, _StoredTransaction] = {}
        self._exchange_tickets: dict[str, _StoredExchangeTicket] = {}
        self._lock = threading.Lock()
        self._repository = repository

    @classmethod
    def from_environment(
        cls,
        *,
        environ: Mapping[str, str] | None = None,
        transaction_ttl_seconds: int = DEFAULT_TRANSACTION_TTL_SECONDS,
        clock: Callable[[], float] = time.time,
        repository: JsonDocumentRepository[_PersistentOAuthRecord] | None = None,
    ) -> OAuthFoundation:
        """Build a foundation from environment-only configuration.

        No provider is contacted.  Missing or partial configuration raises a
        generic error without including any environment value.
        """

        source = os.environ if environ is None else environ
        configuration = _environment_configuration(source)
        selected_repository = repository if repository is not None else _build_persistent_repository(source)
        return cls(
            configuration,
            transaction_ttl_seconds=transaction_ttl_seconds,
            clock=clock,
            repository=selected_repository,
        )

    @property
    def configuration(self) -> OAuthConfiguration:
        """Return validated configuration whose repr redacts provider secrets."""

        return self._configuration

    @property
    def supported_providers(self) -> tuple[OAuthProvider, ...]:
        return tuple(provider for provider in SUPPORTED_PROVIDERS if provider in self._configuration.providers)

    @staticmethod
    def _state_key(state: str) -> str:
        return f"state_{sha256(state.encode('ascii')).hexdigest()}"

    @staticmethod
    def _ticket_key(digest: str) -> str:
        return f"ticket_{digest}"

    def _persist(self, key: str, record: _PersistentOAuthRecord, now: float) -> None:
        repository = self._repository
        if repository is None:
            return
        try:
            for existing_key, existing in repository.items_for_retention():
                if existing.expires_at.timestamp() <= now:
                    repository.delete(existing_key)
            repository.put(key, record)
        except Exception as error:
            raise OAuthTransactionError("OAuth authorization is unavailable") from error

    def _load_persistent(
        self,
        key: str,
        error_type: type[OAuthTransactionError] | type[OAuthExchangeTicketError],
    ) -> _PersistentOAuthRecord:
        repository = self._repository
        if repository is None:
            raise error_type("OAuth state or ticket is unavailable")
        try:
            record = repository.get(key)
        except Exception as error:
            raise error_type("OAuth state or ticket is unavailable") from error
        if not isinstance(record, _PersistentOAuthRecord):
            raise error_type("OAuth state or ticket is unavailable")
        return record

    def _consume_persistent(
        self,
        key: str,
        *,
        now: float,
        error_type: type[OAuthTransactionError] | type[OAuthExchangeTicketError],
        provider: str | None = None,
        kind: Literal["transaction", "exchange_ticket"],
    ) -> _PersistentOAuthRecord:
        record = self._load_persistent(key, error_type)
        if record.kind != kind or record.consumed:
            raise error_type("OAuth state or ticket is unavailable")
        if now >= record.expires_at.timestamp():
            try:
                self._repository.delete(key)  # type: ignore[union-attr]
            except Exception:
                pass
            raise error_type("OAuth state or ticket is expired")
        if provider is not None and record.provider != provider:
            raise error_type("OAuth state provider mismatch")
        version = getattr(self._repository, "version", None)
        if not callable(version):
            raise error_type("OAuth state or ticket is unavailable")
        try:
            expected_version = version(key)
            if expected_version is None:
                raise error_type("OAuth state or ticket is unavailable")
            self._repository.put(key, record.consumed_copy(), expected_version=expected_version)
        except (OAuthTransactionError, OAuthExchangeTicketError):
            raise
        except Exception as error:
            # The expected-version update is the cross-process one-use gate.
            raise error_type("OAuth state or ticket is unavailable") from error
        return record

    @staticmethod
    def _transaction_from_persistent(state: str, record: _PersistentOAuthRecord) -> _StoredTransaction:
        if record.kind != "transaction" or record.state_digest != sha256(state.encode("ascii")).hexdigest():
            raise OAuthTransactionError("OAuth state is invalid or expired")
        required = (record.client_id, record.redirect_uri, record.nonce, record.code_verifier, record.code_challenge)
        if any(value is None for value in required):
            raise OAuthTransactionError("OAuth state is invalid or expired")
        return _StoredTransaction(
            provider=record.provider,
            client_id=cast(str, record.client_id),
            redirect_uri=cast(str, record.redirect_uri),
            return_uri=record.return_uri,
            state=state,
            nonce=cast(str, record.nonce),
            code_verifier=cast(str, record.code_verifier),
            code_challenge=cast(str, record.code_challenge),
            created_at=record.created_at,
            expires_at=record.expires_at.timestamp(),
        )

    @staticmethod
    def _ticket_from_persistent(record: _PersistentOAuthRecord) -> _StoredExchangeTicket:
        if record.kind != "exchange_ticket" or record.account_id is None:
            raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
        return _StoredExchangeTicket(
            provider=record.provider,
            account_id=record.account_id,
            return_uri=record.return_uri,
            created_at=record.created_at,
            expires_at=record.expires_at.timestamp(),
        )

    def create_transaction(
        self,
        provider: str,
        return_uri: str,
    ) -> OAuthAuthorizationRequest:
        """Create a short-lived PKCE transaction without making a network call."""

        provider_config = self._configuration.provider_config(provider)
        if return_uri not in self._configuration.return_uri_allowlist:
            raise OAuthTransactionError("OAuth return URI is not registered")
        # Revalidate at the use boundary in case a configuration object was
        # constructed manually with a mutable allowlist implementation.
        _validate_return_uri(return_uri)

        created_at = float(self._clock())
        expires_at = created_at + self._transaction_ttl_seconds
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        code_verifier = secrets.token_urlsafe(64)
        code_challenge = pkce_s256_challenge(code_verifier)
        redirect_uri = self._configuration.callback_url_for(provider)
        transaction = _StoredTransaction(
            provider=provider_config.provider,
            client_id=provider_config.client_id,
            redirect_uri=redirect_uri,
            return_uri=return_uri,
            state=state,
            nonce=nonce,
            code_verifier=code_verifier,
            code_challenge=code_challenge,
            created_at=created_at,
            expires_at=expires_at,
        )

        with self._lock:
            self._remove_expired(created_at)
            if self._repository is None:
                self._transactions[state] = transaction
            else:
                self._persist(self._state_key(state), _PersistentOAuthRecord.for_transaction(transaction), created_at)

        return OAuthAuthorizationRequest(
            provider=provider_config.provider,
            client_id=provider_config.client_id,
            redirect_uri=redirect_uri,
            return_uri=return_uri,
            state=state,
            code_challenge=code_challenge,
        )

    def validate_and_consume(
        self,
        *,
        state: str,
        provider: str,
    ) -> OAuthTransaction:
        """Validate and atomically consume a transaction exactly once.

        A provider mismatch does not consume a still-valid transaction, allowing
        the legitimate callback to complete.  Expired and successfully consumed
        transactions are removed permanently.
        """

        if not isinstance(state, str) or not state:
            raise OAuthTransactionError("OAuth state is invalid or expired")
        if provider not in SUPPORTED_PROVIDERS:
            raise OAuthTransactionError("OAuth provider is not supported")

        now = float(self._clock())
        if self._repository is not None:
            try:
                consumed = self._consume_persistent(
                    self._state_key(state),
                    now=now,
                    error_type=OAuthTransactionError,
                    provider=provider,
                    kind="transaction",
                )
                return self._transaction_from_persistent(state, consumed).consumed()
            except UnicodeEncodeError as error:
                raise OAuthTransactionError("OAuth state is invalid or expired") from error
        with self._lock:
            transaction = self._transactions.get(state)
            if transaction is None:
                raise OAuthTransactionError("OAuth state is invalid or expired")
            if now >= transaction.expires_at:
                del self._transactions[state]
                raise OAuthTransactionError("OAuth state is expired")
            if transaction.provider != provider:
                raise OAuthTransactionError("OAuth state provider mismatch")
            del self._transactions[state]
            return transaction.consumed()

    def consume_state(self, state: str) -> OAuthTransaction:
        """Consume a valid transaction when the callback has no provider path.

        The provider is bound to the stored state, so the callback does not
        trust a provider name supplied by the browser.
        """

        if not isinstance(state, str) or not state:
            raise OAuthTransactionError("OAuth state is invalid or expired")
        now = float(self._clock())
        if self._repository is not None:
            try:
                consumed = self._consume_persistent(
                    self._state_key(state), now=now, error_type=OAuthTransactionError, kind="transaction"
                )
                return self._transaction_from_persistent(state, consumed).consumed()
            except UnicodeEncodeError as error:
                raise OAuthTransactionError("OAuth state is invalid or expired") from error
        with self._lock:
            transaction = self._transactions.get(state)
            if transaction is None:
                raise OAuthTransactionError("OAuth state is invalid or expired")
            if now >= transaction.expires_at:
                del self._transactions[state]
                raise OAuthTransactionError("OAuth state is expired")
            del self._transactions[state]
            return transaction.consumed()

    def transaction_for_state(self, state: str) -> OAuthTransaction:
        """Read a still-valid transaction for server-side redirect construction."""

        if not isinstance(state, str) or not state:
            raise OAuthTransactionError("OAuth state is invalid or expired")
        now = float(self._clock())
        if self._repository is not None:
            try:
                record = self._load_persistent(self._state_key(state), OAuthTransactionError)
                if record.consumed:
                    raise OAuthTransactionError("OAuth state is invalid or expired")
                if now >= record.expires_at.timestamp():
                    raise OAuthTransactionError("OAuth state is expired")
                return self._transaction_from_persistent(state, record).consumed()
            except UnicodeEncodeError as error:
                raise OAuthTransactionError("OAuth state is invalid or expired") from error
        with self._lock:
            transaction = self._transactions.get(state)
            if transaction is None:
                raise OAuthTransactionError("OAuth state is invalid or expired")
            if now >= transaction.expires_at:
                del self._transactions[state]
                raise OAuthTransactionError("OAuth state is expired")
            return transaction.consumed()

    def issue_exchange_ticket(
        self,
        *,
        provider: str,
        account_id: str,
        return_uri: str,
        ttl_seconds: int = DEFAULT_EXCHANGE_TICKET_TTL_SECONDS,
    ) -> str:
        """Create a short-lived ticket for an already verified OAuth identity."""

        if provider not in SUPPORTED_PROVIDERS or not isinstance(account_id, str) or not account_id:
            raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
        if return_uri not in self._configuration.return_uri_allowlist:
            raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
        if not 1 <= ttl_seconds <= MAX_EXCHANGE_TICKET_TTL_SECONDS:
            raise ValueError("OAuth exchange ticket TTL is outside the allowed range")
        _validate_return_uri(return_uri)
        created_at = float(self._clock())
        opaque_ticket = secrets.token_urlsafe(32)
        stored = _StoredExchangeTicket(
            provider=provider,
            account_id=account_id,
            return_uri=return_uri,
            created_at=created_at,
            expires_at=created_at + ttl_seconds,
        )
        with self._lock:
            self._remove_expired(created_at)
            if self._repository is None:
                self._exchange_tickets[sha256(opaque_ticket.encode("ascii")).hexdigest()] = stored
            else:
                digest = sha256(opaque_ticket.encode("ascii")).hexdigest()
                try:
                    self._persist(self._ticket_key(digest), _PersistentOAuthRecord.for_exchange_ticket(stored), created_at)
                except OAuthTransactionError as error:
                    raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable") from error
        return opaque_ticket

    def consume_exchange_ticket(self, ticket: str) -> OAuthExchangeTicket:
        """Atomically consume a ticket exactly once, never returning its digest."""

        if not isinstance(ticket, str) or not ticket or len(ticket) > 256:
            raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
        try:
            digest = sha256(ticket.encode("ascii")).hexdigest()
        except UnicodeEncodeError as error:
            raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable") from error
        now = float(self._clock())
        if self._repository is not None:
            consumed = self._consume_persistent(
                self._ticket_key(digest), now=now, error_type=OAuthExchangeTicketError, kind="exchange_ticket"
            )
            return self._ticket_from_persistent(consumed).consumed()
        with self._lock:
            stored = self._exchange_tickets.get(digest)
            if stored is None:
                raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
            del self._exchange_tickets[digest]
            if now >= stored.expires_at:
                raise OAuthExchangeTicketError("OAuth exchange ticket is unavailable")
            return stored.consumed()

    def _remove_expired(self, now: float) -> None:
        expired_states = [
            state
            for state, transaction in self._transactions.items()
            if now >= transaction.expires_at
        ]
        for state in expired_states:
            del self._transactions[state]
        expired_tickets = [
            digest
            for digest, ticket in self._exchange_tickets.items()
            if now >= ticket.expires_at
        ]
        for digest in expired_tickets:
            del self._exchange_tickets[digest]


# Short alias for callers that prefer the concise configuration name.
OAuthConfig = OAuthConfiguration

"""Conservative, deterministic checks for evidence needed by a research question.

These checks establish structural coverage, not semantic truth. Evidence must already
be recorded by the runtime; tool-call counts and model-written limitations are not proof.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from datetime import datetime
from hashlib import sha256
import re
from typing import Any

from .research_source_policy import source_eligibility

_METRICS = {
    'revenue': ('revenue', 'sales', '营业收入', '营收', '收入'),
    'diluted_eps': ('diluted eps', 'diluted earnings per share', '稀释每股收益', '稀释eps', '稀释 eps'),
    'basic_eps': ('basic eps', 'basic earnings per share', '基本每股收益', '基本eps', '基本 eps'),
    'eps': ('eps', 'earnings per share', '每股收益'),
}
_COMPARE = ('compare', 'comparison', 'growth', 'change', 'versus', ' vs ', '同比', '增长', '变化', '比较', '对比', '两年', '跨期')
_BENCHMARK = ('benchmark', 'outperform', 'underperform', 'excess return', '基准', '跑赢', '跑输', '超额收益', '大盘')
_COUNTER = ('counterargument', 'counter evidence', 'counter-evidence', 'alternative explanation', '反证', '反方', '替代解释')


def _get(item: Any, key: str, default: Any = None) -> Any:
    return item.get(key, default) if isinstance(item, Mapping) else getattr(item, key, default)


def _metric(text: str) -> str | None:
    t = text.lower()
    for name, words in _METRICS.items():
        if any(word in t for word in words):
            return name
    return None


def _eligible(source: Any, as_of: datetime | None) -> bool:
    if source is None:
        return False
    try:
        return source_eligibility([source], as_of)[0][1] == 'eligible'
    except (AttributeError, TypeError, ValueError):
        return False


def _ref_fact(f: Mapping[str, Any]) -> dict[str, Any]:
    return {'fact_id': f['fact_id']}


def _period_key(s: str) -> tuple[int, str] | None:
    year = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', s)
    if not year:
        return None
    t = s.lower().replace(' ', '')
    if any(x in t for x in ('ytd', '累计', 'year-to-date', 'nine months', 'ninemonths', '9months')):
        return None  # Cumulative windows need an explicit comparable duration.
    half = re.search(r'(?:h([12])|([12])h)', t)
    if half:
        return int(year.group()), 'h' + next(x for x in half.groups() if x)
    quarter = re.search(r'(?:q([1-4])|([1-4])q|第([一二三四1-4])季度)', t)
    if quarter:
        return int(year.group()), 'q' + next(x for x in quarter.groups() if x)
    if any(x in t for x in ('half', 'h1', 'h2', '半年', '6months', 'sixmonths', 'ytd', '累计')):
        return int(year.group()), 'cumulative'
    if any(x in t for x in ('fy', 'annual', 'year', '年度', '年报', '全年')) or re.fullmatch(r'(?:19|20)\d{2}年?', t):
        return int(year.group()), 'annual'
    return None


def _valid_facts(state: Mapping[str, Any], sources: Mapping[str, Any], as_of: datetime | None) -> list[Mapping[str, Any]]:
    out = []
    for f in [*(state.get('prior_facts') or []), *(state.get('facts') or [])]:
        if not isinstance(f, Mapping) or not f.get('fact_id') or not _eligible(sources.get(f.get('source_id')), as_of):
            continue
        source = sources[f['source_id']]
        start, end = f.get('character_start'), f.get('character_end')
        if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(source.text):
            continue
        if f.get('quotation') != source.text[start:end]:
            continue
        out.append(f)
    return out


def assess(question: str, state: Mapping[str, Any], sources: Mapping[str, Any], *, as_of: datetime | None = None,
           claims: Sequence[Any] = (), conflicts: Sequence[Mapping[str, Any]] = ()) -> list[dict[str, Any]]:
    q = question.strip()
    if not q:
        return []
    lower = q.lower()
    segments = [x.strip(' ,，;；?？') for x in re.split(r'\s+(?:and|also|then)\s+|[;；?？]|以及|并且|并|，|和', q, flags=re.I) if x.strip(' ,，;；?？')]
    def located(cit: Any) -> bool:
        sid, quote = _get(cit, 'source_id'), _get(cit, 'quotation')
        source = sources.get(sid)
        if not _eligible(source, as_of) or not isinstance(quote, str) or not quote:
            return False
        return any(isinstance(r, Mapping) and r.get('source_id') == sid and type(r.get('start')) is int
                   and type(r.get('end')) is int and quote in source.text[r['start']:r['end']]
                   for r in [*(state.get('prior_read_ranges') or []), *(state.get('read_ranges') or [])])
    facts = _valid_facts(state, sources, as_of)
    by_id = {f['fact_id']: f for f in facts}
    calcs = [c for c in [*(state.get('prior_calculations') or []), *(state.get('calculations') or [])] if isinstance(c, Mapping)]
    parts = [p for p in state.get('question_parts') or [] if isinstance(p, Mapping)]
    rows: list[dict[str, Any]] = []

    def add(kind: str, text: str, status: str, reason: str, refs: list[dict[str, Any]], **extra: Any) -> None:
        stable = sha256((q + '\0' + kind).encode()).hexdigest()[:16]
        rows.append({'id': 'req-' + stable, 'question': text, 'status': status, 'reason': reason,
                     'references': refs, 'core': True, 'kind': kind, **extra})

    metrics = [name for name, words in _METRICS.items() if any(w in lower for w in words)]
    if 'diluted_eps' in metrics or 'basic_eps' in metrics:
        metrics = [x for x in metrics if x != 'eps']
    compare = any(c in lower for c in _COMPARE)
    for metric in metrics:
        names = {n.casefold() for n in re.findall(r'(?<![A-Za-z0-9])[A-Z][A-Za-z]{1,}(?![A-Za-z0-9])', q)
                 if n.casefold() not in {'what', 'which', 'how', 'compare', 'comparison', 'explain', 'revenue', 'eps', 'diluted', 'basic', 'fy', 'usd', 'eur'}}
        single = re.match(r'^([A-Z])\s+(?=[一-龥])', q)
        if single:
            names.add(single.group(1).casefold())
        def correct_entity(f: Mapping[str, Any]) -> bool:
            if not names:
                return True
            src = sources.get(f.get('source_id'))
            evidence = ' '.join(str(x or '') for x in (f.get('entity'), f.get('entity_id'), f.get('label'), f.get('quotation'), getattr(src, 'title', ''))).casefold()
            return all(re.search(r'(?<![a-z0-9])' + re.escape(name) + r'(?![a-z0-9])', evidence) for name in names)
        fragment = next((x for x in segments if _metric(x) == metric), q)
        requested_years = {int(y) for y in re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', q)}
        matching = [f for f in facts if _metric(str(f.get('label', ''))) == metric and correct_entity(f)
                    and (not requested_years or (_period_key(str(f.get('period', '')))
                         and _period_key(str(f.get('period', '')))[0] in requested_years))]
        refs = [_ref_fact(f) for f in matching]
        status, reason = ('partial', 'Recorded evidence exists; comparable periods and the requested calculation still need verification.') if matching else ('missing', 'No eligible recorded fact matches this metric.')
        requested_quarter = re.search(r'(?i)\bq([1-4])\b|第([一二三四1-4])季度', q)
        if requested_quarter:
            quarter = requested_quarter.group(1) or requested_quarter.group(2)
            matching = [f for f in matching if (key := _period_key(str(f.get('period', '')))) and key[1] == 'q' + quarter]
            refs = [_ref_fact(f) for f in matching]
            if not matching:
                status, reason = 'missing', 'No eligible recorded fact matches the requested metric and quarter.'
        if not compare and matching:
            status, reason = 'satisfied', 'An eligible, located fact matches the requested metric; semantic interpretation remains subject to review.'
        elif compare:
            for calc in calcs:
                inputs = calc.get('inputs') or []
                ids = [i.get('fact_id') for i in inputs if isinstance(i, Mapping)]
                pair = [by_id[x] for x in ids if x in by_id]
                if len(pair) != 2 or len(set(ids)) != 2 or any(_metric(str(f.get('label', ''))) != metric or not correct_entity(f) for f in pair):
                    continue
                periods = [_period_key(str(f.get('period', ''))) for f in pair]
                if not all(periods) or periods[0][1] != periods[1][1] or periods[0][0] <= periods[1][0]:
                    continue
                requested_years = {int(y) for y in re.findall(r'(?<!\d)(?:19|20)\d{2}(?!\d)', q)}
                if requested_years and not requested_years.issubset({p[0] for p in periods}):
                    continue
                if not all(f.get('unit') for f in pair) or pair[0].get('unit') != pair[1].get('unit') or pair[0].get('currency') != pair[1].get('currency'):
                    continue
                # Explicit entity/scope labels must agree; missing entity is not silently inferred across sources.
                entities = [str(f.get('entity') or f.get('entity_id') or '').strip().lower() for f in pair]
                if entities[0] != entities[1] or (not entities[0] and pair[0]['source_id'] != pair[1]['source_id']):
                    continue
                # Compare label prefixes as a second guard against different issuers in a shared document.
                def label_scope(f: Mapping[str, Any]) -> str:
                    label = str(f.get('label', '')).lower()
                    for word in _METRICS[metric]:
                        label = label.replace(word, '')
                    return re.sub(r'\b(?:fy)?(?:19|20)\d{2}\b|[^a-z一-龥]+', '', label)
                if label_scope(pair[0]) != label_scope(pair[1]):
                    continue
                if calc.get('input_status') in ('invalid', 'stale', 'missing') or calc.get('period_order_check') == 'not_checked' or calc.get('period_granularity_check') == 'not_checked':
                    continue
                formula = str(calc.get('formula_id') or '')
                if not any(x in formula for x in ('growth', 'change', 'difference')):
                    continue
                status, reason = 'satisfied', 'Two ordered, comparable recorded inputs are bound to a saved change calculation; entity and scope still require semantic review.'
                refs = [_ref_fact(f) for f in pair] + [{'calculation_id': calc.get('calculation_id')}]
                break
        if not compare and not matching:
            # A located direct quotation may answer a single-period disclosure without manufacturing a fact.
            for claim in claims:
                text = str(_get(claim, 'text', ''))
                citations = _get(claim, 'citations', []) or []
                if (_get(claim, 'role') == 'support' and _metric(text) == metric
                    and all(str(y) in text or any(str(y) in str(_get(c, 'quotation', '')) for c in citations) for y in requested_years)
                    and all(any(re.search(r'(?<![a-z0-9])' + re.escape(name) + r'(?![a-z0-9])', (text + ' ' + str(_get(c, 'quotation', ''))).casefold()) for c in citations) for name in names)
                    and any(located(c) for c in citations) and _get(claim, 'claim_id')):
                    refs = [{'claim_id': _get(claim, 'claim_id')}]
                    status, reason = 'satisfied', 'A located claim addresses the metric and requested period; semantic support needs review.'
                    break
        relevant_conflicts = [c for c in conflicts if _metric(str(c.get('metric', ''))) == metric
                              and (not requested_years or any(str(y) in str(c.get('period', '')) for y in requested_years))
                              and (not names or str(c.get('entity_hint') or '').casefold() in names)]
        asks_conflict = any(c in lower for c in ('conflict', 'disagree', 'discrepancy', '冲突', '不一致', '分歧'))
        if asks_conflict and not relevant_conflicts:
            status, reason = ('partial' if matching else 'missing'), 'The requested conflict has not been established by comparable independent evidence.'
        if relevant_conflicts:
            # A question asking whether a disagreement exists is answered by the conflict itself.
            status, reason = ('satisfied', 'The requested conflict is established; retain each source and value.') if asks_conflict else ('conflict', 'Material conflicting evidence for this metric remains unresolved.')
            if asks_conflict:
                refs = [{'source_id': v['source_id']} for c in relevant_conflicts for v in c.get('values', [])
                        if isinstance(v, Mapping) and v.get('source_id') in sources and _eligible(sources[v['source_id']], as_of)]
        add('financial:' + metric, fragment, status, reason, refs, metric=metric)

    if any(x in lower for x in _BENCHMARK):
        from .research_return_context import price_return_context
        returns = [c for c in calcs if isinstance(c.get('return_context'), Mapping) and c.get('calculation_id')
                   and price_return_context(c, by_id, sources) == c['return_context']]
        valid = None
        for i, left in enumerate(returns):
            for right in returns[i + 1:]:
                a, b = left['return_context'], right['return_context']
                if not a.get('identity_verified') or not b.get('identity_verified') or not a.get('instrument') or not b.get('instrument') or str(a['instrument']).upper() == str(b['instrument']).upper():
                    continue
                if not all(re.search(r'(?<![A-Za-z0-9])' + re.escape(str(x.get('instrument')).split('@')[0]) + r'(?![A-Za-z0-9])', q, re.I) for x in (a, b)):
                    continue
                if not a.get('start_date') or not a.get('end_date') or a['start_date'] > a['end_date'] or (a['start_date'] == a['end_date'] and not all(c.get('start_price_type') == 'open' and c.get('end_price_type') == 'close' for c in (a, b))) or (a['start_date'], a['end_date']) != (b.get('start_date'), b.get('end_date')):
                    continue
                if not a.get('price_basis') or a['price_basis'] == 'unknown' or a['price_basis'] != b.get('price_basis') or a.get('entry_type') != b.get('entry_type') or a.get('entry_type') in ('issue_price', 'unknown', None):
                    continue
                raw_requested = any(w in lower for w in ('unadjusted', '未复权', '原始价格'))
                adjusted_requested = not raw_requested and any(w in lower for w in ('adjusted', '调整', '复权'))
                if (raw_requested and a['price_basis'] != 'raw') or (adjusted_requested and a['price_basis'] != 'adjusted'):
                    continue
                explicit_dates = re.findall(r'\d{4}-\d{2}-\d{2}', q)
                if explicit_dates and (len(explicit_dates) != 2 or tuple(explicit_dates) != (a['start_date'], a['end_date'])):
                    continue
                if any(not all(inp.get('fact_id') in by_id for inp in c.get('inputs', []) if isinstance(inp, Mapping)) or len(c.get('inputs', [])) < 2 for c in (left, right)):
                    continue
                valid = (left, right)
                break
            if valid:
                break
        market_refs = []
        if not valid:
            from .research_market_analytics import AnalyzeMarketSeriesRequest, analyze_market_series
            for entry in [*(state.get('prior_market_analyses') or []), *(state.get('market_analyses') or [])]:
                if not isinstance(entry, Mapping):
                    continue
                try:
                    request = AnalyzeMarketSeriesRequest.model_validate(entry.get('request'))
                    actual = analyze_market_series(request, sources=sources, as_of=as_of, allow_simulated=False)
                    benchmark = actual.get('benchmark') or {}
                    target_symbol = str(actual.get('instrument') or '').split('@')[0]
                    bench_symbol = str(benchmark.get('benchmark_instrument') or '').split('@')[0]
                    dates = (benchmark.get('aligned_start_date'), benchmark.get('aligned_end_date'))
                    def named(symbol: str) -> bool:
                        return bool(symbol and re.search(r'(?<![A-Za-z0-9])' + re.escape(symbol) + r'(?![A-Za-z0-9])', q, re.I))
                    reason = (request.benchmark_selection_reason or '').strip().lower()
                    justified = bool(bench_symbol and bench_symbol.lower() in reason and len(reason) >= 20 and
                                     any(w in reason for w in ('index', 'market', 'sector', 'industry', '指数', '市场', '行业')))
                    # Explicit benchmark tokens must match; unnamed choices require a recorded selection reason.
                    explicit_tickers = {x.upper() for x in re.findall(r'(?<![A-Za-z0-9])[A-Z]{2,6}(?![A-Za-z0-9])', q)} - {'IPO', 'EPS', 'USD', 'ETF', 'FY'}
                    roles_match = named(target_symbol) and (named(bench_symbol) or (len(explicit_tickers) <= 1 and justified))
                    explicit_dates = re.findall(r'\d{4}-\d{2}-\d{2}', q)
                    raw_requested = any(w in lower for w in ('unadjusted', '未复权', '原始价格'))
                    adjusted_requested = not raw_requested and any(w in lower for w in ('adjusted', '调整', '复权'))
                    basis_mismatch = (adjusted_requested and request.price_basis != 'adjusted') or (raw_requested and request.price_basis != 'raw')
                    if (not roles_match or basis_mismatch or target_symbol.upper() == bench_symbol.upper() or benchmark.get('aligned_bar_count', 0) < 2
                        or not all(dates) or dates[0] >= dates[1] or (explicit_dates and (len(explicit_dates) != 2 or tuple(explicit_dates) != dates))):
                        continue
                    if actual != entry.get('result'):
                        continue
                    market_refs = [{'analysis_id': entry['analysis_id']}] if entry.get('analysis_id') else [{'source_id': sid} for sid in actual['source_ids']]
                    break
                except (ValueError, TypeError, KeyError, AttributeError):
                    continue
        add('market:benchmark', q, 'satisfied' if valid or market_refs else 'missing',
            'Distinct instruments have returns over the same dates and price basis; verify their requested roles.' if valid or market_refs else 'Need distinct target and benchmark returns over at least two common dates, using the same price basis.',
            [{'calculation_id': c['calculation_id']} for c in valid] if valid else market_refs)

    if any(x in lower for x in _COUNTER):
        valid = [c for c in claims if _get(c, 'role') == 'counterargument' and _get(c, 'challenges_claim_ids') and
                 any(located(cit) for cit in (_get(c, 'citations', []) or []))]
        negative = []
        for search in state.get('counter_searches') or []:
            if not isinstance(search, Mapping) or search.get('scope') != 'document' or search.get('status') != 'completed' or search.get('matches') != 0:
                continue
            target, hypothesis, query, sid = (str(search.get(k) or '').strip() for k in ('target', 'hypothesis', 'query', 'source_id'))
            linked = bool(target and (target.casefold() in lower or any(target == _get(c, 'claim_id') or target.casefold() == str(_get(c, 'text', '')).casefold() for c in claims)))
            if linked and hypothesis and query and _eligible(sources.get(sid), as_of):
                negative.append(search)
        if valid:
            status, reason = 'satisfied', 'A cited counterargument explicitly identifies the challenged claim.'
            refs = [{'claim_id': _get(c, 'claim_id')} for c in valid if _get(c, 'claim_id')]
        elif negative:
            item = negative[0]
            status, reason = 'satisfied', f"Targeted search for {item['hypothesis']} found no match for {item['query']} in source {item['source_id']}; this does not exclude evidence elsewhere."
            refs = [{'source_id': item['source_id']}]
        else:
            status, reason, refs = 'missing', 'A targeted counterargument or scoped negative search needs an identified claim, alternative and eligible source; a generic search is insufficient.', []
        add('counterevidence', q, status, reason, refs)

    # A request solely to draw or transform a chart is fulfilled by a saved,
    # source-authorized chart of the requested kind, not by an unrelated claim.
    chart_task = bool(re.fullmatch(r'(?i)(?:draw|create|make|convert|change|update|redraw|绘制|生成|转换|改为)[^?？;；]{0,100}\b(?:chart|graph|map|图表|图|图形)(?:[^?？;；]{0,60})', q))
    chart_refs = []
    if chart_task and not metrics and not any(x in lower for x in (*_BENCHMARK, *_COUNTER)):
        for chart in state.get('charts') or []:
            if not isinstance(chart, Mapping) or not chart.get('chart_id') or not chart.get('source_ids'):
                continue
            if not all(_eligible(sources.get(sid), as_of) for sid in chart['source_ids']):
                continue
            kind = chart.get('chart_type')
            if any(x in lower for x in ('causal', '因果', '传导')) and kind != 'causal_graph':
                continue
            if any(x in lower for x in ('line', '折线')) and kind != 'line':
                continue
            if any(x in lower for x in ('convert', 'change', '转换', '改为')) and not chart.get('replaces_chart_id'):
                continue
            if 'billion' in lower and not any(axis.get('scale') == 'billions' for axis in chart.get('axes', []) if isinstance(axis, Mapping)):
                continue
            chart_refs.append({'chart_id': chart['chart_id']})
        add('chart', q, 'satisfied' if chart_refs else 'missing',
            'A saved chart uses eligible sources; assumptions remain labelled.' if chart_refs else 'A source-backed chart of the requested kind is required.', chart_refs)

    # Preserve independently requested clauses that did not select a method.
    unknown = [] if chart_task and chart_refs else [x for x in segments if not any(w in x.lower() for words in _METRICS.values() for w in words)
               and not any(w in x.lower() for w in (*_BENCHMARK, *_COUNTER))]
    if not rows:
        unknown = [q]
    for fragment in unknown:
        # A model checkpoint is only a candidate: references must survive current source and cutoff checks.
        matched = [p for p in parts if p.get('question') == fragment and p.get('status') == 'answered' and p.get('answer')]
        refs = [ref for p in matched for ref in p.get('references', []) if isinstance(ref, Mapping) and ref.get('fact_id') in by_id]
        claims_by_id = {_get(c, 'claim_id'): c for c in claims if _get(c, 'claim_id')}
        for p in matched:
            for ref in p.get('references', []):
                if not isinstance(ref, Mapping):
                    continue
                claim = claims_by_id.get(ref.get('claim_id'))
                if claim and _get(claim, 'role') == 'support' and any(located(c) for c in (_get(claim, 'citations', []) or [])):
                    refs.append({'claim_id': ref['claim_id']})
                sid, start, end = ref.get('source_id'), ref.get('character_start'), ref.get('character_end')
                src = sources.get(sid)
                if (_eligible(src, as_of) and type(start) is int and type(end) is int and 0 <= start < end <= len(src.text)
                    and any(isinstance(r, Mapping) and r.get('source_id') == sid and r.get('start', -1) <= start < end <= r.get('end', -1)
                            for r in [*(state.get('prior_read_ranges') or []), *(state.get('read_ranges') or [])])):
                    refs.append({'source_id': sid, 'character_start': start, 'character_end': end})
        stop = {'what', 'which', 'when', 'where', 'how', 'does', 'did', 'the', 'this', 'that', 'with', 'from', 'have', 'were', 'was', 'are', 'is', 'for', 'and', 'explain', 'summarize', 'disclose', 'provide', 'please'}
        terms = {w for w in re.findall(r'[a-z0-9]{3,}', fragment.lower()) if w not in stop}
        cjk_terms = {fragment[i:i+2] for i in range(len(fragment)-1) if re.fullmatch(r'[一-龥]{2}', fragment[i:i+2])}
        if terms or cjk_terms:
            for claim in claims:
                claim_text = str(_get(claim, 'text', ''))
                text_terms = set(re.findall(r'[a-z0-9]{3,}', claim_text.lower()))
                overlap = bool(terms & text_terms or any(w in claim_text for w in cjk_terms))
                absent = bool(re.search(r'\b(?:not disclosed|no disclosure|not mentioned)\b|未披露|没有披露|未提及', claim_text, re.I))
                complete = any(_eligible(sources.get(_get(c, 'source_id')), as_of) and
                               any(isinstance(r, Mapping) and r.get('source_id') == _get(c, 'source_id') and r.get('start') == 0
                                   and r.get('end', 0) >= len(sources[_get(c, 'source_id')].text)
                                   for r in [*(state.get('prior_read_ranges') or []), *(state.get('read_ranges') or [])])
                               for c in (_get(claim, 'citations', []) or []))
                conditions_requested = any(w in fragment.lower() for w in ('condition', '条件', '限定'))
                conditions_addressed = any(w in claim_text.lower() for w in ('condition', 'subject to', 'provided that', '条件', '须', '需', '前提', '批准'))
                if (overlap and (not conditions_requested or conditions_addressed) and (not absent or complete) and _get(claim, 'role') == 'support' and _get(claim, 'claim_id')
                    and any(located(c) for c in (_get(claim, 'citations', []) or []))):
                    refs.append({'claim_id': _get(claim, 'claim_id')})
        add('generic:' + fragment, fragment, 'satisfied' if refs else 'missing',
            'A checkpoint binds the complete question to eligible recorded facts; semantic support needs review.' if refs else 'The complete question needs an answer linked to eligible evidence; coverage cannot be inferred from tool calls.', refs)
    return rows

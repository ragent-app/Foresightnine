import type { EvidenceItem, ProbabilityAssessment, ThesisDocument, Worldline } from "@foresightnine/contracts";
import { DEFAULT_FRESHNESS_POLICY, evaluateFreshness, type FreshnessPolicy, type FreshnessDecision, type ProviderFreshnessStatus } from "@foresightnine/domain";
import { sha256Hex, type ComputeFmInput, type FactorExpression } from "@foresightnine/fm-engine";
import { computeAnchorFactorMetrics, computeMarketSnapshotIntegrityHash, createMockMarketSnapshotBundle, marketDataStatus, marketSnapshotBundleToFmInput, SNAPSHOT_ANCHORS, type MarketSnapshotBundle } from "@foresightnine/market-data";
import type { AssetFixture, BranchView, Currency, EvidenceView, FreshnessOptions } from "./types";

export const MARKET_DATA_AS_OF = "2026-08-09";
export const RUNTIME_AS_OF = "2026-08-09T00:00:00Z";
/** Runtime clock for the live app; tests should pass an explicit deterministic value. */
export const DEFAULT_RUNTIME_AS_OF = new Date().toISOString();
/** Offline fixtures never establish current-market freshness. */
export const PROVIDER_FRESHNESS_STATUS: ProviderFreshnessStatus = "unavailable";
export const FRESHNESS_POLICY: FreshnessPolicy = DEFAULT_FRESHNESS_POLICY;
export const FX_SNAPSHOT = {
  asOf: MARKET_DATA_AS_OF,
  provider: "fixture-fx-snapshot",
  label: "deterministic mock FX snapshot; not live market data",
  cnyPerUnit: { CNY: 1, USD: 7.18, EUR: 7.82 } as const,
} as const;

export const PUBLIC_CONSTRAINTS = {
  methodVersion: "Public-Default-v1",
  singleSecurityMax: 0.25,
  highVolatilityClassMax: 0.35,
  longOnly: true,
  fullyInvested: true,
  noLeverage: true,
  staleDataAllowed: false,
  lowLiquidityAllowed: false,
} as const;

const metadata = { schema_version: "v1" as const, created_at: "2026-08-10T00:00:00Z", source_refs: [{ ref_id: "fixture:web", source_type: "model_inference" as const, label: "Web offline fixture" }], content_hash: "fixture-web" };

export const ASSET_FIXTURES: readonly AssetFixture[] = [
  { assetId: "GRID", displayName: "电网基础设施", economicExposureId: "grid-infrastructure", instrumentId: "GRID-ETF", assetClass: "etf", quoteCurrency: "USD", price: 120, lotSize: 1, fractionalSupported: false, tradable: false, proxyInstrument: "GRID-ETF", liquidity: "high", volatility: "low", asOf: MARKET_DATA_AS_OF, freshness: "current" },
  { assetId: "CHIP", displayName: "半导体基础设施", economicExposureId: "semiconductor-infrastructure", instrumentId: "CHIP", assetClass: "equity", quoteCurrency: "USD", price: 80, lotSize: 1, fractionalSupported: false, tradable: true, liquidity: "high", volatility: "high", asOf: MARKET_DATA_AS_OF, freshness: "current" },
  { assetId: "UTIL", displayName: "公用事业", economicExposureId: "utilities", instrumentId: "UTIL", assetClass: "etf", quoteCurrency: "CNY", price: 36, lotSize: 1, fractionalSupported: true, tradable: true, liquidity: "medium", volatility: "low", asOf: MARKET_DATA_AS_OF, freshness: "current" },
  { assetId: "GOLD", displayName: "黄金对冲", economicExposureId: "gold", instrumentId: "GOLD-ETF", assetClass: "commodity_etf", quoteCurrency: "EUR", price: 12, lotSize: 1, fractionalSupported: false, tradable: true, liquidity: "medium", volatility: "high", asOf: MARKET_DATA_AS_OF, freshness: "current" },
  { assetId: "WORLD", displayName: "全球股票", economicExposureId: "global-equity", instrumentId: "WORLD", assetClass: "etf", quoteCurrency: "USD", price: 90, lotSize: 1, fractionalSupported: true, tradable: true, liquidity: "low", volatility: "low", asOf: MARKET_DATA_AS_OF, freshness: "historical_only" },
  { assetId: "CASH", displayName: "现金等价物", economicExposureId: "cash", instrumentId: "CASH", assetClass: "cash", quoteCurrency: "CNY", price: 1, lotSize: 1, fractionalSupported: true, tradable: true, liquidity: "high", volatility: "low", asOf: MARKET_DATA_AS_OF, freshness: "current" },
];

export const demoThesis = (viewpoint: string, capital: number, currency: Currency): ThesisDocument => ({
  ...metadata,
  thesis_id: "thesis-web-demo",
  session_id: "session-web-demo",
  raw_text: viewpoint,
  normalized_premise: viewpoint,
  horizon: "24 months",
  trigger_events: ["用户观点中的可观察触发事件", "需求或政策披露", "订单与现金流验证"],
  claimed_asset_impacts: ["电网基础设施", "半导体基础设施", "公用事业"],
  capital,
  base_currency: currency,
  user_private_evidence_claims: false,
  status: "DRAFT",
});

export function evidenceHash(item: Pick<EvidenceView, "evidence_id" | "challenge_id" | "source_type" | "url" | "title" | "publisher" | "published_at" | "retrieved_at" | "excerpt" | "user_note" | "grade" | "supports_or_challenges" | "independently_reviewable" | "search_provider" | "search_result_hash">): string {
  return sha256Hex(JSON.stringify({ evidence_id: item.evidence_id, challenge_id: item.challenge_id, source_type: item.source_type, url: item.url, title: item.title, publisher: item.publisher, published_at: item.published_at, retrieved_at: item.retrieved_at, excerpt: item.excerpt, user_note: item.user_note, grade: item.grade, supports_or_challenges: item.supports_or_challenges, independently_reviewable: item.independently_reviewable, search_provider: item.search_provider ?? null, search_result_hash: item.search_result_hash ?? null }));
}

export interface SourceMaterialHashInput {
  readonly url: string | null;
  readonly title: string;
  readonly published_at: string | null;
  readonly retrieved_at: string;
  readonly search_provider?: string | null;
  readonly search_result_hash?: string | null;
  readonly excerpt: string;
  readonly user_note: string;
}

function normalizeApiDateTime(value: string | null): string | null {
  const trimmed = value?.trim() ?? "";
  if (!trimmed) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return `${trimmed}T00:00:00`;
  const match = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/i.exec(trimmed);
  if (!match) return trimmed;
  const fraction = match[3] && /[1-9]/.test(match[3]) ? `.${match[3].slice(0, 6).padEnd(6, "0")}` : "";
  const timezone = match[4] ? (match[4].toUpperCase() === "Z" ? "+00:00" : match[4]) : "";
  return `${match[1]}T${match[2]}${fraction}${timezone}`;
}

/** API-compatible subset hash; distinct from the full Web audit hash above. */
export function sourceMaterialHash(item: SourceMaterialHashInput): string {
  return sha256Hex(JSON.stringify({
    excerpt: item.excerpt,
    published_at: normalizeApiDateTime(item.published_at),
    retrieved_at: normalizeApiDateTime(item.retrieved_at),
    search_provider: item.search_provider?.trim() || null,
    search_result_hash: item.search_result_hash?.trim() || null,
    title: item.title,
    url: item.url?.trim() || null,
    user_note: item.user_note,
  }));
}

export function isEvidenceIndependentlyReviewable(grade: EvidenceView["grade"], sourceType: EvidenceView["source_type"], url: string): boolean {
  return (grade === "A" || grade === "B" || grade === "C") && sourceType !== "user_private" && sourceType !== "model_inference" && Boolean(url.trim());
}

function makeEvidence(item: Omit<EvidenceView, "sourceLabel" | "publisher" | "content_hash" | "retrieved_at" | "challenge_id"> & { sourceLabel: string; challenge_id?: string; retrieved_at?: string }): EvidenceView {
  const retrievedAt = item.retrieved_at ?? `${MARKET_DATA_AS_OF}T00:00:00Z`;
  const base = {
    ...metadata,
    evidence_id: item.evidence_id,
    challenge_id: item.challenge_id ?? "challenge-web-demo",
    source_type: item.source_type,
    url: item.url,
    title: item.title,
    publisher: item.sourceLabel,
    published_at: item.published_at,
    retrieved_at: retrievedAt,
    excerpt: item.excerpt,
    user_note: item.user_note,
    grade: item.grade,
    supports_or_challenges: item.supports_or_challenges,
    independently_reviewable: isEvidenceIndependentlyReviewable(item.grade, item.source_type, item.url),
    ...(item.search_provider && item.search_result_hash ? { search_provider: item.search_provider, search_result_hash: item.search_result_hash } : {}),
    sourceLabel: item.sourceLabel,
  };
  return { ...base, content_hash: evidenceHash(base), fixture: true };
}

export const searchEvidenceFixture: EvidenceView = makeEvidence({
  evidence_id: "evidence-search-1", title: "IEA 数据中心电力需求与电网投资摘要", source_type: "reliable_secondary", grade: "B", sourceLabel: "IEA · deterministic offline fixture", published_at: "2024-10-01", excerpt: "公开摘要用于验证需求增长与电网投资的方向；具体数字仍需回到原始报告核验。", user_note: "fixture: 仅用于离线验证 SearchEvidenceBundle 字段闭环。", supports_or_challenges: "supports", independently_reviewable: true, url: "https://www.iea.org/", fixture: true,
});

export const privateEvidenceFixture: EvidenceView = makeEvidence({
  evidence_id: "evidence-private-1", title: "行业专家访谈摘要", source_type: "user_private", grade: "D", sourceLabel: "用户私有声明 · fixture", published_at: "2026-08-09", excerpt: "专家认为订单可见度改善，但访谈本身不能替代公开证据。", user_note: "不可独立复核；保留为用户私有前提，不作为公开事实。", supports_or_challenges: "context", independently_reviewable: false, url: "", fixture: true,
});

function assessment(id: string, worldlineId: string, conditional: number, minimum: number, maximum: number): ProbabilityAssessment {
  return { ...metadata, assessment_id: id, worldline_id: worldlineId, premise_probability: 0.42, premise_probability_range: { minimum: 0.35, maximum: 0.49 }, conditional_probability: conditional, conditional_probability_range: { minimum, maximum }, joint_probability: 0.42 * conditional, joint_probability_range: { minimum: 0.35 * minimum, maximum: 0.49 * maximum }, confidence: "medium", base_rate_refs: [], adjustment_reasons: ["支持证据向上", "反对证据向下", "模型不确定性：区间加宽"], calibration_status: "model_estimate_unvalidated" };
}

function worldline(kind: BranchView["kind"], title: string, description: string, premise: string, suffix: string): Worldline {
  const id = `wl-${kind}-web-${suffix}`;
  const nodes: Worldline["nodes"] = [
    { node_id: `${id}-0`, time_window: "现在", event_date: "2026-08-10", data_as_of: MARKET_DATA_AS_OF, event: "观点基线与需求信号", observable_indicators: ["用户观点", "公开需求披露"], causal_parents: [], state_changes: ["观察窗口开始"], confidence: "medium" },
    { node_id: `${id}-1`, time_window: "+6 个月", event_date: "2027-02-10", data_as_of: MARKET_DATA_AS_OF, event: kind === "weak" ? "需求与投资指引走弱" : kind === "strong" ? "政策与融资提前加速" : "需求与投资指引确认", observable_indicators: ["投资计划", "设备订单"], causal_parents: [`${id}-0`], state_changes: [kind === "weak" ? "订单斜率下修" : "订单斜率改变"], confidence: kind === "main" ? "high" : "medium" },
    { node_id: `${id}-2`, time_window: "+12 个月", event_date: "2027-08-10", data_as_of: MARKET_DATA_AS_OF, event: "传导结果可见", observable_indicators: ["订单交付", "利用率", "现金流"], causal_parents: [`${id}-1`], state_changes: ["现金流验证"], confidence: "medium" },
    { node_id: `${id}-3`, time_window: "+24 个月", event_date: "2028-08-10", data_as_of: MARKET_DATA_AS_OF, event: "估值再定价或失效", observable_indicators: ["利润兑现", "需求修正"], causal_parents: [`${id}-2`], state_changes: ["路径结算"], confidence: "low" },
  ];
  const revealDates = ["2026-08-10", "2027-02-28", "2027-08-31", "2028-08-31"];
  return { ...metadata, worldline_id: id, bundle_id: `bundle-web-${suffix}`, branch_kind: kind, title, premise, baseline_date: "2026-08-10", horizon_end: "2028-08-31", nodes, edges: [{ from_node_id: `${id}-0`, to_node_id: `${id}-1` }, { from_node_id: `${id}-1`, to_node_id: `${id}-2` }, { from_node_id: `${id}-2`, to_node_id: `${id}-3` }], asset_anchors: ["GRID", "CHIP", "UTIL"], asset_impacts: [], event_reveal_schedule: nodes.map((node, index) => ({ event_id: node.node_id, event_date: node.event_date, reveal_date: revealDates[index]!, rule: "scheduled" as const })), invalidation_conditions: [kind === "weak" ? "需求与投资没有恢复" : "需求增长低于用户观点中的基线", kind === "strong" ? "融资收紧或政策约束" : "资本开支指引连续下修"], provenance: "offline deterministic fixture; consumes user viewpoint; model estimate", status: "WORLDLINE_READY" };
}

export function makeBranches(viewpoint: string): readonly BranchView[] {
  const premise = viewpoint.trim() || "尚未提供观点；请先返回输入页。";
  const suffix = sha256Hex(premise).slice(0, 8);
  return [
    { kind: "weak", title: "弱情景 W−", range: "20–35%", color: "weak", description: `「${premise}」中的传导低于预期，订单或需求延后。`, reveal: "需求与订单没有按观点展开", invalidation: "需求下修、投资周期延迟", nodes: ["传导走弱", "资本开支延后", "估值压缩"], assessment: assessment(`assessment-weak-${suffix}`, `wl-weak-web-${suffix}`, 0.27, 0.20, 0.35), worldline: worldline("weak", "需求与投资延迟", `「${premise}」未能形成足够传导。`, premise, suffix) },
    { kind: "main", title: "主情景 W₀", range: "45–62%", color: "main", description: `「${premise}」按部分路径兑现，设备与基础设施投资逐步验证。`, reveal: "订单增速与现金流可见", invalidation: "需求增速持续低于观点基线", nodes: ["观点触发", "投资指引", "订单增速", "估值再定价"], assessment: assessment(`assessment-main-${suffix}`, `wl-main-web-${suffix}`, 0.54, 0.45, 0.62), worldline: worldline("main", "投资按计划兑现", `「${premise}」按计划传导。`, premise, suffix) },
    { kind: "strong", title: "强情景 W+", range: "12–25%", color: "strong", description: `「${premise}」触发二阶效应，政策与融资共同加速扩容。`, reveal: "订单和政策信号同时超预期", invalidation: "融资收紧、政策约束", nodes: ["需求加速", "资本开支提前", "订单超预期", "估值扩张"], assessment: assessment(`assessment-strong-${suffix}`, `wl-strong-web-${suffix}`, 0.19, 0.12, 0.25), worldline: worldline("strong", "政策与融资共振", `「${premise}」产生二阶效应。`, premise, suffix) },
  ];
}

export const branches: readonly BranchView[] = makeBranches("如果未来两年全球数据中心电力需求持续上升，并推动电网设备投资提速，那么电网设备与相关基础设施将受益。");

export function freshnessFor(asset: AssetFixture, options: FreshnessOptions = { runtimeAsOf: RUNTIME_AS_OF, providerStatus: PROVIDER_FRESHNESS_STATUS }): FreshnessDecision {
  return evaluateFreshness({ dataAsOf: asset.asOf, runtimeAsOf: options.runtimeAsOf, providerStatus: options.providerStatus, declaredFreshness: asset.freshness }, options.policy ?? FRESHNESS_POLICY);
}

export function isPublicEligible(asset: AssetFixture, options: FreshnessOptions = { runtimeAsOf: RUNTIME_AS_OF, providerStatus: PROVIDER_FRESHNESS_STATUS }): boolean {
  const freshness = freshnessFor(asset, options);
  return hasCurrentFx(options, ["CNY", asset.quoteCurrency]) && (asset.tradable || Boolean(asset.proxyInstrument)) && (asset.liquidity === "high" || asset.liquidity === "medium") && freshness.allowCurrentPublicDefault;
}

export function fxToBase(quoteCurrency: Currency, baseCurrency: Currency, cnyPerUnit: Readonly<Record<string, number>> = FX_SNAPSHOT.cnyPerUnit): number {
  const quoteRate = cnyPerUnit[quoteCurrency];
  const baseRate = cnyPerUnit[baseCurrency];
  if (typeof quoteRate !== "number" || typeof baseRate !== "number" || !Number.isFinite(quoteRate) || !Number.isFinite(baseRate) || quoteRate <= 0 || baseRate <= 0) return Number.NaN;
  return quoteRate / baseRate;
}

export function hasCurrentFx(options: FreshnessOptions, currencies: readonly string[] = ["CNY", "USD", "EUR"]): boolean {
  if (options.fxProviderStatus !== "fresh" || !options.fxAsOf || !options.fxCnyPerUnit) return false;
  const fxDecision = evaluateFreshness({ dataAsOf: options.fxAsOf, runtimeAsOf: options.runtimeAsOf, providerStatus: options.fxProviderStatus }, options.policy ?? FRESHNESS_POLICY);
  return fxDecision.allowCurrentPublicDefault && currencies.every((currency) => {
    const rate = options.fxCnyPerUnit?.[currency];
    return typeof rate === "number" && Number.isFinite(rate) && rate > 0;
  });
}

export const FM_FACTORS: readonly FactorExpression[] = [
  { id: 10, icMean: 0.072, icir: 0.64, admitted: true, expression: { op: "field", name: "momentum" } },
  { id: 20, icMean: 0.051, icir: 0.58, admitted: true, expression: { op: "field", name: "quality" } },
  { id: 30, icMean: -0.044, icir: -0.52, admitted: true, expression: { op: "rank", input: { op: "field", name: "momentum" } } },
];

/** Explicit offline fallback bundle. A future configured provider must replace this at acquisition time. */
export const MARKET_SNAPSHOT_BUNDLE: MarketSnapshotBundle = createMockMarketSnapshotBundle({ assetIds: ASSET_FIXTURES.map((asset) => asset.assetId), cutoff: MARKET_DATA_AS_OF, timezone: "UTC", requestedAt: "2026-08-09T00:00:00Z" });
export const MARKET_DATA_STATUS = marketDataStatus(MARKET_SNAPSHOT_BUNDLE);

export function assetsForMarketBundle(bundle: MarketSnapshotBundle): readonly AssetFixture[] {
  const latest = new Map(bundle.snapshots.filter((row) => row.anchor === "latest_completed_session").map((row) => [row.assetId, row]));
  return ASSET_FIXTURES.map((asset) => {
    if (asset.assetClass === "cash" || asset.assetId === "CASH") return asset;
    const row = latest.get(asset.assetId);
    const price = row?.close ?? row?.price;
    if (!row || row.status === "missing" || price === null || price === undefined || !Number.isFinite(price) || price <= 0) {
      throw new Error(`No usable latest completed-session price for ${asset.assetId}.`);
    }
    if (row.currency !== "CNY" && row.currency !== "USD" && row.currency !== "EUR") {
      throw new Error(`Unsupported quote currency for ${asset.assetId}.`);
    }
    return {
      ...asset,
      price,
      quoteCurrency: row.currency,
      asOf: row.asOf ?? bundle.cutoff.slice(0, 10),
      freshness: row.status === "stale" ? "stale" : "current",
    };
  });
}

/** Live licensed bundles derive IC/ICIR from the three price anchors; vendor momentum/RSI/SMA-derived features drive the FM factors. */
export const LIVE_FM_FACTOR_TEMPLATES: readonly FactorExpression[] = [
  { id: 10, icMean: 0, icir: 0, admitted: true, expression: { op: "field", name: "momentum" } },
  { id: 11, icMean: 0, icir: 0, admitted: true, expression: { op: "field", name: "momentum_month" } },
  { id: 12, icMean: 0, icir: 0, admitted: true, expression: { op: "field", name: "rsi14" } },
  { id: 13, icMean: 0, icir: 0, admitted: true, expression: { op: "field", name: "sma_ratio" } },
  { id: 30, icMean: 0, icir: 0, admitted: true, expression: { op: "rank", input: { op: "field", name: "momentum" } } },
];

export function fmFactorsForBundle(bundle: MarketSnapshotBundle): readonly FactorExpression[] {
  if (bundle.provider.mode === "mock") return FM_FACTORS;
  const metrics = computeAnchorFactorMetrics(bundle, LIVE_FM_FACTOR_TEMPLATES);
  return LIVE_FM_FACTOR_TEMPLATES.map((template) => {
    const metric = metrics.find((entry) => entry.factorId === template.id);
    if (metric === undefined || !metric.sufficient) return { ...template, admitted: false };
    return { ...template, icMean: metric.icMean, icir: metric.icir, admitted: true };
  });
}

function factorFields(expression: FactorExpression["expression"], fields = new Set<string>()): ReadonlySet<string> {
  switch (expression.op) {
    case "field": fields.add(expression.name); break;
    case "constant": break;
    case "add": case "sub": case "mul": case "div":
      factorFields(expression.left, fields);
      factorFields(expression.right, fields);
      break;
    case "neg": case "abs": case "rank": case "rolling_mean": case "rolling_std":
      factorFields(expression.input, fields);
      break;
  }
  return fields;
}

function factorHasCompleteInputs(factor: FactorExpression, bundle: MarketSnapshotBundle): boolean {
  return [...factorFields(factor.expression)].every((field) => bundle.snapshots.every((row) => {
    const value = field === "close" ? (row.close ?? row.price) : row.features?.[field];
    return value !== null && value !== undefined && Number.isFinite(value);
  }));
}

export function fmInput(bundle: MarketSnapshotBundle = MARKET_SNAPSHOT_BUNDLE): ComputeFmInput {
  // Cash is the portfolio residual rather than a priced factor exposure.  A
  // provider is allowed to return three explicit `missing` CASH rows; exclude
  // that dimension from Raw FM instead of making the whole research flow
  // impossible. Historical anchors marked stale remain usable for Raw only,
  // while the freshness layer continues to block Public Default execution.
  const cashRows = bundle.snapshots.filter((row) => row.assetId === "CASH");
  const cashIsExplicitlyMissing = cashRows.length === SNAPSHOT_ANCHORS.length && cashRows.every((row) => row.status === "missing");
  const fmAssetIds = cashIsExplicitlyMissing ? bundle.assets.filter((assetId) => assetId !== "CASH") : bundle.assets;
  const fmSnapshots = bundle.snapshots.filter((row) => fmAssetIds.includes(row.assetId));
  const fmBase = { ...bundle, assets: fmAssetIds, snapshots: fmSnapshots };
  const fmBundle: MarketSnapshotBundle = { ...fmBase, integrityHash: computeMarketSnapshotIntegrityHash(fmBase) };
  const currentByAsset = new Map(ASSET_FIXTURES.map((asset, index) => [asset.assetId, [280, 200, 180, 140, 120, 80][index]!]));
  // Providers may expose a declared feature with null values (for example,
  // momentum when the available history is shorter than its lookback).  FM
  // evaluates every expression, including non-admitted factors, so omit only
  // expressions whose required cells are incomplete and retain all complete
  // factors.  This preserves a truthful limited-data result without allowing
  // one unavailable feature to abort the whole local computation.
  const usableFactors = fmFactorsForBundle(fmBundle).filter((factor) => factorHasCompleteInputs(factor, fmBundle));
  const converted = marketSnapshotBundleToFmInput(fmBundle, usableFactors, { currentValues: Float64Array.from(fmAssetIds.map((assetId) => currentByAsset.get(assetId) ?? 0)), maxFactors: 10, initialAllocation: true, costBps: 3 });
  const completeCells = converted.input.observations.every((observation) => Object.values(observation.fields).every((values) => values.length === fmAssetIds.length && values.every((value) => value !== null && Number.isFinite(value))));
  if (!completeCells) throw new Error("The market snapshot bundle has missing non-cash factor cells and cannot drive Raw FM.");
  return converted.input;
}

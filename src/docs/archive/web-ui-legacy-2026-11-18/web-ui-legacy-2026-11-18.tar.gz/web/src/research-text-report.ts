import type { ResearchV2 } from "@foresightnine/contracts";

// A text report is a view of the server-authorized export, not a new export
// permission boundary. All untrusted text stays plain text and is confined to
// one labeled line so embedded line breaks cannot impersonate report fields.
function scalar(value: unknown, missing: string): string {
  if (value === undefined || value === null || value === "") return missing;
  if (typeof value === "string") return value.replace(/[\u0000-\u001f\u007f]/g, (c) => c === "\n" ? "\\n" : c === "\r" ? "\\r" : c === "\t" ? "\\t" : " ");
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return JSON.stringify(value);
}

export function formatResearchTextReport(data: ResearchV2.ResearchFullExport, en: boolean): string {
  const missing = en ? "not recorded" : "未记录";
  const label = (english: string, chinese: string) => en ? english : chinese;
  const lines: string[] = [];
  const add = (name: string, value: unknown) => lines.push(`${name}: ${scalar(value, missing)}`);
  const section = (name: string) => lines.push("", `== ${name} ==`);
  const items = (value: unknown): readonly Readonly<Record<string, unknown>>[] => Array.isArray(value)
    ? value.filter((item): item is Readonly<Record<string, unknown>> => Boolean(item) && typeof item === "object" && !Array.isArray(item)) : [];
  const empty = (count: number) => { if (!count) lines.push(label("None recorded.", "未记录。")); };
  const v = data.version, c = v.content;
  lines.push(label("ForesightNine research report", "ForesightNine 研究报告"));
  add(label("Topic question", "主题原问题"), data.request.question);
  if (typeof c.run?.question_override === "string") add(label("Question for this version", "本版本的研究问题"), c.run.question_override);
  add(label("Scope", "范围"), data.request.scope);
  add(label("Research cutoff", "研究截止时间"), data.request.as_of);
  add(label("Topic ID", "主题标识"), data.topic_id);
  add(label("Version ID", "版本标识"), v.version_id);
  add(label("Parent version", "上一版本"), v.parent_version_id);
  add(label("Version created", "版本创建时间"), v.created_at);
  add(label("Exported", "导出时间"), data.generated_at);
  add(label("Review state", "复核状态"), v.review);
  add(label("Version author", "版本创建方"), v.created_by);
  add(label("Version note", "版本备注"), v.note);
  add(label("Last run state (not a new review)", "上次运行状态（不代表新的复核）"), c.run?.status);
  lines.push(label("Model interpretations and declared source permissions are not independently verified.", "模型解释及声明的资料权限尚未独立核验。"));
  lines.push(label("Calculations use recorded inputs; source precision and prior rounding are not established.", "计算使用已记录的输入；来源精度及此前舍入情况尚未确认。"));
  if (c.summary) { section(label("Summary", "摘要")); add(label("Summary", "摘要"), c.summary); }
  section(label("Findings and counterarguments", "结论与反方"));
  empty(items(c.claims).length);
  items(c.claims).forEach((claim, i) => {
    lines.push(`\n${label("Finding", "条目")} ${i + 1}`);
    for (const [key, a, b] of [["role", "Role", "类型"], ["claim_id", "Finding ID", "条目标识"], ["responds_to_claim_ids", "Related finding IDs (not verified)", "关联结论标识（未经核验）"], ["suggested_responds_to_claim_ids", "Model-suggested finding IDs (not verified)", "模型建议的关联结论标识（未经核验）"], ["responds_to_omitted", "Omitted invalid relationships", "已省略的无效关联数"], ["text", "Text", "内容"], ["authorship", "Authorship", "作者类型"], ["kind", "Kind", "内容类型"], ["verification", "Verification", "核验状态"], ["support_status", "Support status", "支持状态"], ["absence_scope_status", "Absence scope status (not established)", "缺失结论范围状态（尚未成立）"], ["support_review", "Model review (not independent)", "模型复查（非独立核验）"]] as const) add(label(a,b), claim[key]);
    const evidenceClaims = (c.run?.evidence_links as { claims?: { claim_id?: string; assertions?: unknown[]; assertion_coverage?: string }[] } | undefined)?.claims;
    const claimLinks = Array.isArray(evidenceClaims) ? evidenceClaims.find((row) => row.claim_id === claim.claim_id) : undefined;
    if (claimLinks) add(label("Suggested finding breakdown (not verified)", "建议的结论分项（未经核验）"), {coverage: claimLinks.assertion_coverage, assertions: claimLinks.assertions});
    for (const citation of items(claim.citations)) {
      add(label("Citation source", "引文来源"), citation.source_id);
      add(label("Quotation", "引文"), citation.quotation);
      add(label("Location", "位置"), citation.location);
      add(label("Quotation status", "引文状态"), {match: citation.quotation_match ?? null, partial_token: citation.partial_token ?? false, support: citation.support_status ?? null});
    }
    if (claim.user_fact_links !== undefined) add(label("User-declared figure links (not verified)", "用户关联数值（未经核验）"), claim.user_fact_links);
    if (claim.user_fact_links_omitted !== undefined) add(label("Omitted figure links", "未保留的数值关联数"), claim.user_fact_links_omitted);
    for (const key of ["source_scope_absence_unverified", "causal_attribution_unverified", "counterpoint_relevance_unverified", "prior_findings_truncated", "prior_findings_scope_unverified", "uncited_exact_dates", "publication_date_warnings", "rate_unit_warnings", "uncited_amounts", "uncited_claim_amounts", "uncited_dollar_amounts", "uncited_quarters", "balance_direction_warnings", "uncited_percentages", "percentage_unit_unverified", "uncited_percentage_bounds", "reused_percentages", "uncited_basis_points", "uncited_percentage_points", "uncited_fact_values", "citation_context_warnings", "suggested_fact_evidence", "suggested_related_quotations", "suggested_calculations"]) if (claim[key] !== undefined) add(key, claim[key]);
  });
  section(label("Extracted figures", "提取的数值"));
  empty(items(c.facts).length);
  items(c.facts).forEach((fact, i) => {
    lines.push(`\n${label("Figure", "数值")} ${i + 1}`);
    for (const [key, a, b] of [["fact_id","ID","标识"],["label","Metric","指标"],["value","Value","数值"],["unit","Unit","单位"],["currency","Currency","币种"],["period","Period","期间"],["verification","Verification","核验状态"],["authorship","Authorship","作者类型"],["source_id","Source ID","来源标识"],["quotation","Quotation","引文"],["quotation_match","Quotation match","引文定位方式"],["location","Location","位置"]] as const) add(label(a,b), fact[key]);
    for (const key of ["extraction_method", "structured_metadata", "currency_context_unverified", "currency_quote_missing", "scale_quote_missing", "table_alignment_unverified", "table_period_conflict", "table_structure_alignment", "xbrl_source_consistency", "table_confirmation", "currency_conflict_unverified", "currency_unspecified", "direction_context_unverified", "direction_confirmation", "source_value_warnings", "numeric_normalization", "range_parent_id"]) if (fact[key] !== undefined) add(key, fact[key]);
  });
  section(label("Calculations", "计算"));
  empty(items(c.calculations).length);
  items(c.calculations).forEach((calculation, i) => {
    lines.push(`\n${label("Calculation", "计算")} ${i + 1}`);
    // Preserve every stored input, formula, precision and status, including
    // fields introduced by later compatible schema versions.
    for (const [key, value] of Object.entries(calculation)) add(key, value);
    const links = (c.run?.evidence_links as { calculations?: { calculation_index?: number; inputs?: unknown[] }[] } | undefined)?.calculations;
    const record = Array.isArray(links) ? links.find((item) => item.calculation_index === i) : undefined;
    if (record) add(label("Recorded input source locations (context not independently verified)", "记录的输入来源位置（上下文未独立核验）"), record.inputs);
  });
  if (c.run?.pdf_structure_diagnostics !== undefined) add(label("PDF geometry mapping (not a whole-document verification)", "PDF 几何映射（不代表全文核验）"), c.run.pdf_structure_diagnostics);
  if (Array.isArray(c.run?.acquisition_decisions)) add(label("Evidence decisions (not independent proof)", "取证决定（不代表独立核验）"), c.run.acquisition_decisions.map((item: unknown) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return null;
    const row = item as Record<string, unknown>;
    const pick = (value: unknown, allowed: string[]) => typeof value === "string" && allowed.includes(value) ? value : "unknown";
    const requirement = typeof row.requirement_id === "string" && (row.requirement_id === "user_request" || /^question:[0-9a-f]{8,64}$/.test(row.requirement_id)) ? row.requirement_id : null;
    const sourceIds = Array.isArray(row.source_ids) ? row.source_ids.filter((id: unknown) => typeof id === "string" && /^source_[0-9a-f]{32}$/.test(id)) : [];
    const ranges = Array.isArray(row.selected_ranges) ? row.selected_ranges.flatMap((value: unknown) => {
      if (!value || typeof value !== "object" || Array.isArray(value)) return [];
      const range = value as Record<string, unknown>;
      return typeof range.source_id === "string" && sourceIds.includes(range.source_id) && Number.isSafeInteger(range.character_start) && Number.isSafeInteger(range.character_end)
        ? [{source_id: range.source_id, character_start: range.character_start, character_end: range.character_end}] : [];
    }) : [];
    return {round: Number.isSafeInteger(row.round) ? row.round : null, requirement_id: requirement,
      action: pick(row.action, ["discover", "retrieve", "structured", "read", "counterpoint", "review", "deliver", "deliver_partial", "next_page"]),
      reason_code: pick(row.reason_code, ["selected", "unavailable", "no_source", "missing_evidence", "unresolved_requirement", "conflict", "review_conflict", "not_reviewed", "no_progress", "no_actionable_source", "sufficient"]),
      result_status: pick(row.result_status, ["completed", "success", "selected", "stopped", "attempted", "partial", "failed", "unavailable", "restricted", "not_requested", "no_evidence", "no_progress", "unknown"]),
      source_ids: sourceIds, selected_ranges: ranges, remaining_gaps_recorded: Array.isArray(row.remaining_gap_codes) && row.remaining_gap_codes.length > 0,
      stop_reason: pick(row.stop_reason, ["evidence_reviewed", "partial_delivery", "no_progress", "no_actionable_source", "sufficient"])};
  }));
  if (Array.isArray(c.run?.evidence_rounds)) add(label("Evidence collection rounds (leads are not evidence)", "自主取证轮次（线索不是证据）"), c.run.evidence_rounds.map((item: unknown) => {
    if (!item || typeof item !== "object") return null;
    const row = item as Record<string, unknown>;
    return {round: row.round, status: row.status, search_status: row.search_status, new_source_ids: row.new_source_ids, new_ranges: row.new_ranges, remaining_source_ids: row.remaining_source_ids,
      outcomes: Array.isArray(row.outcomes) ? row.outcomes.map((outcome: unknown) => {
        if (!outcome || typeof outcome !== "object") return null;
        const result = outcome as Record<string, unknown>;
        return {candidate_index: result.candidate_index, status: result.status, source_id: result.source_id};
      }) : []};
  }));
  if (c.run?.source_quality !== undefined) add(label("Recorded source identity and duplication (not independent verification)", "记录的来源身份与重复关系（非独立核验）"), c.run.source_quality);
  section(label("Sources and provenance", "来源与追溯信息"));
  empty(data.source_provenance.length);
  data.source_provenance.forEach((source, i) => {
    lines.push(`\n${label("Source", "来源")} ${i + 1}`);
    for (const [key, value] of Object.entries(source)) add(key, value);
  });
  if (items(c.sources).length) {
    section(label("Initial prompt source selection (not proof of comprehension)", "首次模型输入资料范围（不证明模型理解）"));
    items(c.sources).forEach((source, i) => {
      add(`${label("Source", "来源")} ${i + 1}`, source.title ?? source.source_id);
      add(label("Extracted text coverage", "提取文本选取范围"), source.initial_prompt_coverage);
    });
  }
  if (c.run && Object.keys(c.run).length) {
    section(label("Recorded run", "已记录的运行"));
    for (const [key, value] of Object.entries(c.run)) add(key, value);
  }
  section(label("Limitations and outstanding checks", "局限与待核查项"));
  if (!c.limitations?.length) lines.push(label("None recorded.", "未记录。"));
  c.limitations?.forEach((value, i) => add(String(i + 1), value));
  for (const [key, values] of [["evidence_differences", c.evidence_differences], ["calculation_differences", c.calculation_differences], ["amount_differences", c.amount_differences], ["source_candidates", c.source_candidates]] as const) {
    if (values?.length) { section(key); values.forEach((value, i) => add(String(i + 1), value)); }
  }
  lines.push("", label("For the complete structured record, export the research JSON separately.", "完整结构化记录可另行导出研究 JSON。"));
  return lines.join("\n") + "\n";
}

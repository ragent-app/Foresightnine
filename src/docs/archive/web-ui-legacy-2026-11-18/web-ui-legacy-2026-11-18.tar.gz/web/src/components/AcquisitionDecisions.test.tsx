import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { AcquisitionDecisions } from "./AcquisitionDecisions";

describe("evidence decisions", () => {
  it("does not invent records for old versions", () => {
    expect(renderToStaticMarkup(<AcquisitionDecisions value={undefined} en={false} />)).toBe("");
  });
  it("shows recorded outcomes and leaves unsupported meanings unknown", () => {
    const html = renderToStaticMarkup(<AcquisitionDecisions en={false} value={[{
      requirement_id:"user_request", action:"discover", reason_code:"missing_evidence", result_status:"failed",
      source_ids:[], selected_ranges:[], remaining_gap_codes:["unresolved"], stop_reason:"no_progress",
      secret:"must-not-show", url:"https://private.example/secret",
    }]} />);
    expect(html).toContain("原问题"); expect(html).toContain("寻找资料");
    expect(html).toContain("仍需补充依据"); expect(html).toContain("失败");
    expect(html).toContain("未发现新的可执行进展");
    expect(html).not.toContain("must-not-show"); expect(html).not.toContain("private.example");
  });
  it("renders the recorded structured action and hashed question without exposing extra fields", () => {
    const html = renderToStaticMarkup(<AcquisitionDecisions en={false} value={[{
      round: 2, requirement_id: "question:0123456789abcdef01234567", action: "structured",
      tool: "structured_source", reason_code: "selected", result_status: "stopped",
      source_ids: ["source_0123456789abcdef0123456789abcdef"],
      selected_ranges: [{source_id: "source_0123456789abcdef0123456789abcdef", character_start: 10, character_end: 42}],
      remaining_gap_codes: ["unresolved"], context_omitted: {sources: 2}, context_page: 1,
      stop_reason: "partial_delivery", query_sha256: "a".repeat(64),
    }]} />);
    expect(html).toContain("研究问题 (01234567)");
    expect(html).toContain("获取结构化数据");
    expect(html).toContain("针对当前研究选择");
    expect(html).toContain("已停止");
    expect(html).toContain("交付已有成果并保留缺口");
    expect(html).toContain("[10, 42)");
    expect(html).not.toContain("a".repeat(64));
  });
});

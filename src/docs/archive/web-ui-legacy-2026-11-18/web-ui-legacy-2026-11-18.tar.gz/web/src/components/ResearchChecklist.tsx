interface Props { value: unknown; en: boolean }

type Cue = { code: string; indexes?: number[]; index_kind?: string; count?: number; truncated?: boolean };

const labels: Record<string, readonly [string, string]> = {
  suggested_requirement_unlinked: ["A model-suggested requirement has no linked evidence.", "模型建议的要求尚无关联证据。"],
  suggested_calculation_unlinked: ["A model-suggested calculation has no linked result.", "模型建议的计算尚未关联结果。"],
  no_analyzed_sources: ["No source was analyzed in the last run.", "上次运行没有已分析的来源。"],
  source_processing_incomplete: ["Some selected sources were excluded or not fully selected for the initial prompt.", "部分已选资料被排除，或未完整选入首次模型输入。"],
  source_scope_review_required: ["Review missing-information conclusions against the material actually selected.", "请根据实际选入的资料复核关于信息缺失的结论。"],
  absence_observation_unestablished: ["A model-suggested absence has not been established.", "模型提出的信息缺失尚未确认。"],
  model_suggested_evidence_need: ["A proposed evidence need has not been independently verified.", "建议补充的证据尚未独立核验。"],
  no_findings: ["No finding was retained.", "没有保留研究结论。"],
  subquestions_unlinked: ["Some model-suggested subquestions have no linked finding.", "部分模型建议的子问题没有关联结论。"],
  citations_missing_or_incomplete: ["Findings have missing or incomplete citations.", "部分研究条目缺少完整引文。"],
  semantic_support_not_independently_verified: ["Citation support has not been independently verified.", "引文是否支持结论尚未独立核验。"],
  evidence_warnings: ["Evidence warnings require review.", "部分研究条目存在证据警示，需要核查。"],
  user_fact_links_omitted: ["Some user-declared figure links were omitted and require review.", "部分用户关联的数值未保留，需要重新核查。"],
  no_counterpoint: ["A counterargument was requested but none was retained.", "本次要求反方，但没有保留反方条目。"],
  counterpoint_target_unlinked: ["Counterarguments have no recorded or suggested finding to review against.", "部分反方未关联或建议关联具体结论。"],
  counterpoint_relevance_unverified: ["Counterpoint relevance was not supported by the requested model review.", "请求的模型复查未确认部分反方与原结论相关。"],
  calculation_inputs_unverified: ["Calculation inputs are missing, changed or not verified.", "部分计算的输入缺失、变更或尚未核查。"],
  calculation_results_unverified: ["Some saved calculation results do not match the engine or cannot be recomputed.", "部分已保存计算结果与引擎重算不一致或无法重算。"],
  calculation_or_amount_differences: ["Potential differences between findings, amounts or calculations require review.", "结论、金额或计算存在待核查差异。"],
  research_planning_incomplete: ["The requested research plan did not complete.", "请求的研究规划未完成。"],
  gap_source_search_incomplete: ["The requested gap-focused source search did not complete.", "请求的缺口来源搜索未完成。"],
  gap_followup_incomplete: ["The requested evidence-gap follow-up did not complete.", "请求的证据缺口补充未完成。"],
  model_review_incomplete: ["The requested model review did not finish for all findings.", "请求的模型复查未覆盖全部条目。"],
  model_review_does_not_support: ["The model review found insufficient citation support for these items; verify its assessment.", "模型复查认为这些条目的引文不支持结论，请核查该判断。"],
  model_review_contradiction: ["The model review identified possible contradictions; verify the evidence.", "模型复查发现可能的矛盾，请核查证据。"],
  model_review_uncertain: ["The model review was uncertain about citation support for these items.", "模型复查无法确定这些条目的引文是否支持结论。"],
  model_review_missing: ["The requested model review has no recorded opinion for these items.", "请求的模型复查没有为这些条目留下判断。"],
  counterpoint_followup_incomplete: ["The requested counterargument follow-up did not complete.", "请求的反方补充未完成。"],
  last_run_partial: ["The last run returned partial results; review its limitations.", "上次运行部分完成，请查看其限制和缺口。"],
};

export function ResearchChecklist({ value, en }: Props) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const data = value as { schema_version?: string; items?: unknown };
  if (data.schema_version !== "1" || !Array.isArray(data.items)) return null;
  const items = (data.items as Cue[]).filter((item) => item && typeof item.code === "string" && labels[item.code]);
  return <section className="general-source">
    <h3>{en ? "Review checklist" : "研究待核查项"}</h3>
    <p>{en ? "Generated from the saved record. An empty checklist does not verify the findings, prove evidence support or rule out other gaps." : "根据已保存记录生成。待办为空不代表结论已核实、证据充分或不存在其他缺口。"}</p>
    {items.length ? <ul>{items.map((item) => <li key={item.code}>{labels[item.code]?.[en ? 0 : 1] ?? item.code}
      {Array.isArray(item.indexes) && item.indexes.length ? <span> {item.index_kind === "calculation" ? (en ? "Calculations" : "计算") : item.index_kind === "question" ? (en ? "Subquestions" : "子问题") : (en ? "Items" : "研究条目")} {item.indexes.filter(Number.isInteger).map((i) => i + 1).join("、")}{item.truncated ? (en ? " (additional items omitted)" : "（还有未列出的条目）") : ""}.</span> : null}
    </li>)}</ul> : <p>{en ? "No recorded checklist items." : "没有已记录的待核查项。"}</p>}
  </section>;
}

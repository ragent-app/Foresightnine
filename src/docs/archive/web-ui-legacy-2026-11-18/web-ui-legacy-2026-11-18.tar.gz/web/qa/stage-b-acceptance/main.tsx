import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { GeneralResearch } from '../../src/components/GeneralResearch';
import '../../src/styles.css';

// Isolated UI harness. The companion browser script supplies all API responses.
function Harness() {
  const [account, setAccount] = useState('qa-account-a');
  return <><button onClick={() => setAccount(account === 'qa-account-a' ? 'qa-account-b' : 'qa-account-a')}>Switch mock account</button>
    <GeneralResearch key={account} baseUrl={new URLSearchParams(location.search).get('api') || location.origin} accountId={account} language="en" /></>;
}
createRoot(document.getElementById('root')!).render(<Harness />);
